* b05 T5/T6: retroceso del lector y ruido de alimentación
.lib /foss/pdks/sky130A/libs.tech/ngspice/sky130.lib.spice tt
.include /foss/pdks/sky130A/libs.ref/sky130_fd_sc_hd/spice/sky130_fd_sc_hd.spice
.options gmin=1e-15 abstol=1e-15 reltol=1e-4
.temp 27
.subckt canal vdd slo smid c pre a h x y rd=100 cab=50f
XR1 vdd h 0 sky130_fd_pr__res_high_po_0p35 l=56
XR2 h 0 0 sky130_fd_pr__res_high_po_0p35 l=0.5
XRhi h a 0 sky130_fd_pr__res_xhigh_po_0p35 l=52
XMmid h smid m1 0 sky130_fd_pr__nfet_01v8 w=1 l=0.15
XRmid m1 a 0 sky130_fd_pr__res_xhigh_po_0p35 l=1.75
XMlo h slo a 0 sky130_fd_pr__nfet_01v8 w=5 l=0.15
Rdut a 0 r = {rd*exp(23.03*v(c))}
Cab a 0 {cab}
Cpar a 0 5f
Xc0 vdd vdd c1 0 sky130_fd_pr__nfet_01v8 w=1 l=1
Xc1 c1 c1 vb 0 sky130_fd_pr__nfet_01v8 w=1 l=1
Xc2 vb vb 0 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.15 m=16
Cf vb 0 1p
Xp x pre vdd vdd sky130_fd_pr__pfet_01v8 w=0.42 l=0.15
Xr x vb a 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.15
Xi x 0 0 vdd vdd y sky130_fd_sc_hd__inv_1
.ends
Vdd vdd 0 1.8
Vz z 0 0
Vc c 0 0
Vpre pre 0 pulse(0 1.8 1u 1n 1n 400u 500u)
Vddn vddn 0 pwl(0 1.8 600u 1.8 600.001u 2.0 610u 2.0 610.001u 1.6 620u 1.6)
X5100_0 vdd z z c pre a5_100_0 h5_100_0 x5_100_0 y5_100_0 canal rd=100 cab=0
X6100_0 vddn z z c z a6_100_0 h6_100_0 x6_100_0 y6_100_0 canal rd=100 cab=0
X5100_50f vdd z z c pre a5_100_50f h5_100_50f x5_100_50f y5_100_50f canal rd=100 cab=50f
X6100_50f vddn z z c z a6_100_50f h6_100_50f x6_100_50f y6_100_50f canal rd=100 cab=50f
X512k9_0 vdd z z c pre a5_12k9_0 h5_12k9_0 x5_12k9_0 y5_12k9_0 canal rd=12906 cab=0
X612k9_0 vddn z z c z a6_12k9_0 h6_12k9_0 x6_12k9_0 y6_12k9_0 canal rd=12906 cab=0
X512k9_50f vdd z z c pre a5_12k9_50f h5_12k9_50f x5_12k9_50f y5_12k9_50f canal rd=12906 cab=50f
X612k9_50f vddn z z c z a6_12k9_50f h6_12k9_50f x6_12k9_50f y6_12k9_50f canal rd=12906 cab=50f
X51M_0 vdd z z c pre a5_1M_0 h5_1M_0 x5_1M_0 y5_1M_0 canal rd=1e+06 cab=0
X61M_0 vddn z z c z a6_1M_0 h6_1M_0 x6_1M_0 y6_1M_0 canal rd=1e+06 cab=0
X51M_50f vdd z z c pre a5_1M_50f h5_1M_50f x5_1M_50f y5_1M_50f canal rd=1e+06 cab=50f
X61M_50f vddn z z c z a6_1M_50f h6_1M_50f x6_1M_50f y6_1M_50f canal rd=1e+06 cab=50f
X5ab_0 vdd z z c pre a5_ab_0 h5_ab_0 x5_ab_0 y5_ab_0 canal rd=1e+12 cab=0
X6ab_0 vddn z z c z a6_ab_0 h6_ab_0 x6_ab_0 y6_ab_0 canal rd=1e+12 cab=0
X5ab_50f vdd z z c pre a5_ab_50f h5_ab_50f x5_ab_50f y5_ab_50f canal rd=1e+12 cab=50f
X6ab_50f vddn z z c z a6_ab_50f h6_ab_50f x6_ab_50f y6_ab_50f canal rd=1e+12 cab=50f
.control
tran 5n 620u
meas tran mx5_100_0 max v(a5_100_0) from=0.5u to=590u
meas tran mn5_100_0 min v(a5_100_0) from=0.5u to=590u
meas tran dc5_100_0 find v(a5_100_0) at=0.9u
meas tran tc5_100_0 when v(y5_100_0)=0.9 rise=1
echo T5 R=100 cab=0 reposo=$&dc5_100_0 max=$&mx5_100_0 min=$&mn5_100_0 tconv=$&tc5_100_0
meas tran mx6_100_0 max v(a6_100_0) from=599u to=620u
meas tran mn6_100_0 min v(a6_100_0) from=599u to=620u
echo T6 R=100 cab=0 max=$&mx6_100_0 min=$&mn6_100_0
meas tran mx5_100_50f max v(a5_100_50f) from=0.5u to=590u
meas tran mn5_100_50f min v(a5_100_50f) from=0.5u to=590u
meas tran dc5_100_50f find v(a5_100_50f) at=0.9u
meas tran tc5_100_50f when v(y5_100_50f)=0.9 rise=1
echo T5 R=100 cab=50f reposo=$&dc5_100_50f max=$&mx5_100_50f min=$&mn5_100_50f tconv=$&tc5_100_50f
meas tran mx6_100_50f max v(a6_100_50f) from=599u to=620u
meas tran mn6_100_50f min v(a6_100_50f) from=599u to=620u
echo T6 R=100 cab=50f max=$&mx6_100_50f min=$&mn6_100_50f
meas tran mx5_12k9_0 max v(a5_12k9_0) from=0.5u to=590u
meas tran mn5_12k9_0 min v(a5_12k9_0) from=0.5u to=590u
meas tran dc5_12k9_0 find v(a5_12k9_0) at=0.9u
meas tran tc5_12k9_0 when v(y5_12k9_0)=0.9 rise=1
echo T5 R=12k9 cab=0 reposo=$&dc5_12k9_0 max=$&mx5_12k9_0 min=$&mn5_12k9_0 tconv=$&tc5_12k9_0
meas tran mx6_12k9_0 max v(a6_12k9_0) from=599u to=620u
meas tran mn6_12k9_0 min v(a6_12k9_0) from=599u to=620u
echo T6 R=12k9 cab=0 max=$&mx6_12k9_0 min=$&mn6_12k9_0
meas tran mx5_12k9_50f max v(a5_12k9_50f) from=0.5u to=590u
meas tran mn5_12k9_50f min v(a5_12k9_50f) from=0.5u to=590u
meas tran dc5_12k9_50f find v(a5_12k9_50f) at=0.9u
meas tran tc5_12k9_50f when v(y5_12k9_50f)=0.9 rise=1
echo T5 R=12k9 cab=50f reposo=$&dc5_12k9_50f max=$&mx5_12k9_50f min=$&mn5_12k9_50f tconv=$&tc5_12k9_50f
meas tran mx6_12k9_50f max v(a6_12k9_50f) from=599u to=620u
meas tran mn6_12k9_50f min v(a6_12k9_50f) from=599u to=620u
echo T6 R=12k9 cab=50f max=$&mx6_12k9_50f min=$&mn6_12k9_50f
meas tran mx5_1M_0 max v(a5_1M_0) from=0.5u to=590u
meas tran mn5_1M_0 min v(a5_1M_0) from=0.5u to=590u
meas tran dc5_1M_0 find v(a5_1M_0) at=0.9u
meas tran tc5_1M_0 when v(y5_1M_0)=0.9 rise=1
echo T5 R=1M cab=0 reposo=$&dc5_1M_0 max=$&mx5_1M_0 min=$&mn5_1M_0 tconv=$&tc5_1M_0
meas tran mx6_1M_0 max v(a6_1M_0) from=599u to=620u
meas tran mn6_1M_0 min v(a6_1M_0) from=599u to=620u
echo T6 R=1M cab=0 max=$&mx6_1M_0 min=$&mn6_1M_0
meas tran mx5_1M_50f max v(a5_1M_50f) from=0.5u to=590u
meas tran mn5_1M_50f min v(a5_1M_50f) from=0.5u to=590u
meas tran dc5_1M_50f find v(a5_1M_50f) at=0.9u
meas tran tc5_1M_50f when v(y5_1M_50f)=0.9 rise=1
echo T5 R=1M cab=50f reposo=$&dc5_1M_50f max=$&mx5_1M_50f min=$&mn5_1M_50f tconv=$&tc5_1M_50f
meas tran mx6_1M_50f max v(a6_1M_50f) from=599u to=620u
meas tran mn6_1M_50f min v(a6_1M_50f) from=599u to=620u
echo T6 R=1M cab=50f max=$&mx6_1M_50f min=$&mn6_1M_50f
meas tran mx5_ab_0 max v(a5_ab_0) from=0.5u to=590u
meas tran mn5_ab_0 min v(a5_ab_0) from=0.5u to=590u
meas tran dc5_ab_0 find v(a5_ab_0) at=0.9u
meas tran tc5_ab_0 when v(y5_ab_0)=0.9 rise=1
echo T5 R=ab cab=0 reposo=$&dc5_ab_0 max=$&mx5_ab_0 min=$&mn5_ab_0 tconv=$&tc5_ab_0
meas tran mx6_ab_0 max v(a6_ab_0) from=599u to=620u
meas tran mn6_ab_0 min v(a6_ab_0) from=599u to=620u
echo T6 R=ab cab=0 max=$&mx6_ab_0 min=$&mn6_ab_0
meas tran mx5_ab_50f max v(a5_ab_50f) from=0.5u to=590u
meas tran mn5_ab_50f min v(a5_ab_50f) from=0.5u to=590u
meas tran dc5_ab_50f find v(a5_ab_50f) at=0.9u
meas tran tc5_ab_50f when v(y5_ab_50f)=0.9 rise=1
echo T5 R=ab cab=50f reposo=$&dc5_ab_50f max=$&mx5_ab_50f min=$&mn5_ab_50f tconv=$&tc5_ab_50f
meas tran mx6_ab_50f max v(a6_ab_50f) from=599u to=620u
meas tran mn6_ab_50f min v(a6_ab_50f) from=599u to=620u
echo T6 R=ab cab=50f max=$&mx6_ab_50f min=$&mn6_ab_50f
quit
.endc
.end
