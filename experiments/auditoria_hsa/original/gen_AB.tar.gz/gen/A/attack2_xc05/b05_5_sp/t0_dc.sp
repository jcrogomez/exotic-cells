* b05 T0: continua
.lib /foss/pdks/sky130A/libs.tech/ngspice/sky130.lib.spice tt
.include /foss/pdks/sky130A/libs.ref/sky130_fd_sc_hd/spice/sky130_fd_sc_hd.spice
.options gmin=1e-15 abstol=1e-15 reltol=1e-4
.temp 27
.subckt canal vdd slo smid c pre a h x y rd=100 cab=50f
XR1 vdd h 0 sky130_fd_pr__res_high_po_0p35 l=56
XR2 h 0 0 sky130_fd_pr__res_high_po_0p35 l=0.5
XRhi h a 0 sky130_fd_pr__res_xhigh_po_0p35 l=52
XMmid h smid m1 0 sky130_fd_pr__nfet_01v8 w=1 l=0.15
XRmid m1 a 0 sky130_fd_pr__res_xhigh_po_0p35 l=1.75
XMlo h slo a 0 sky130_fd_pr__nfet_01v8 w=5 l=0.15
Rdut a 0 r = {rd*exp(23.03*v(c))}
Cab a 0 {cab}
Cpar a 0 5f
Xc0 vdd vdd c1 0 sky130_fd_pr__nfet_01v8 w=1 l=1
Xc1 c1 c1 vb 0 sky130_fd_pr__nfet_01v8 w=1 l=1
Xc2 vb vb 0 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.15 m=16
Cf vb 0 1p
Xp x pre vdd vdd sky130_fd_pr__pfet_01v8 w=0.42 l=0.15
Xr x vb a 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.15
Xi x 0 0 vdd vdd y sky130_fd_sc_hd__inv_1
.ends
Vdd vdd 0 1.8
Vc c 0 0
Vpre pre 0 0
Vlo_bajo slo_bajo 0 1.8
Vmid_bajo smid_bajo 0 0
Xbajo0 vdd slo_bajo smid_bajo c pre a_bajo_0 h_bajo_0 x_bajo_0 y_bajo_0 canal rd=30 cab=0
Xbajo1 vdd slo_bajo smid_bajo c pre a_bajo_1 h_bajo_1 x_bajo_1 y_bajo_1 canal rd=100 cab=0
Xbajo2 vdd slo_bajo smid_bajo c pre a_bajo_2 h_bajo_2 x_bajo_2 y_bajo_2 canal rd=300 cab=0
Xbajo3 vdd slo_bajo smid_bajo c pre a_bajo_3 h_bajo_3 x_bajo_3 y_bajo_3 canal rd=1000 cab=0
Xbajo4 vdd slo_bajo smid_bajo c pre a_bajo_4 h_bajo_4 x_bajo_4 y_bajo_4 canal rd=3000 cab=0
Xbajo5 vdd slo_bajo smid_bajo c pre a_bajo_5 h_bajo_5 x_bajo_5 y_bajo_5 canal rd=10000 cab=0
Xbajo6 vdd slo_bajo smid_bajo c pre a_bajo_6 h_bajo_6 x_bajo_6 y_bajo_6 canal rd=12906 cab=0
Xbajo7 vdd slo_bajo smid_bajo c pre a_bajo_7 h_bajo_7 x_bajo_7 y_bajo_7 canal rd=30000 cab=0
Xbajo8 vdd slo_bajo smid_bajo c pre a_bajo_8 h_bajo_8 x_bajo_8 y_bajo_8 canal rd=100000 cab=0
Xbajo9 vdd slo_bajo smid_bajo c pre a_bajo_9 h_bajo_9 x_bajo_9 y_bajo_9 canal rd=300000 cab=0
Xbajo10 vdd slo_bajo smid_bajo c pre a_bajo_10 h_bajo_10 x_bajo_10 y_bajo_10 canal rd=1e+06 cab=0
Xbajo11 vdd slo_bajo smid_bajo c pre a_bajo_11 h_bajo_11 x_bajo_11 y_bajo_11 canal rd=3e+06 cab=0
Xbajo12 vdd slo_bajo smid_bajo c pre a_bajo_12 h_bajo_12 x_bajo_12 y_bajo_12 canal rd=1e+12 cab=0
Vlo_medio slo_medio 0 0
Vmid_medio smid_medio 0 1.8
Xmedio0 vdd slo_medio smid_medio c pre a_medio_0 h_medio_0 x_medio_0 y_medio_0 canal rd=30 cab=0
Xmedio1 vdd slo_medio smid_medio c pre a_medio_1 h_medio_1 x_medio_1 y_medio_1 canal rd=100 cab=0
Xmedio2 vdd slo_medio smid_medio c pre a_medio_2 h_medio_2 x_medio_2 y_medio_2 canal rd=300 cab=0
Xmedio3 vdd slo_medio smid_medio c pre a_medio_3 h_medio_3 x_medio_3 y_medio_3 canal rd=1000 cab=0
Xmedio4 vdd slo_medio smid_medio c pre a_medio_4 h_medio_4 x_medio_4 y_medio_4 canal rd=3000 cab=0
Xmedio5 vdd slo_medio smid_medio c pre a_medio_5 h_medio_5 x_medio_5 y_medio_5 canal rd=10000 cab=0
Xmedio6 vdd slo_medio smid_medio c pre a_medio_6 h_medio_6 x_medio_6 y_medio_6 canal rd=12906 cab=0
Xmedio7 vdd slo_medio smid_medio c pre a_medio_7 h_medio_7 x_medio_7 y_medio_7 canal rd=30000 cab=0
Xmedio8 vdd slo_medio smid_medio c pre a_medio_8 h_medio_8 x_medio_8 y_medio_8 canal rd=100000 cab=0
Xmedio9 vdd slo_medio smid_medio c pre a_medio_9 h_medio_9 x_medio_9 y_medio_9 canal rd=300000 cab=0
Xmedio10 vdd slo_medio smid_medio c pre a_medio_10 h_medio_10 x_medio_10 y_medio_10 canal rd=1e+06 cab=0
Xmedio11 vdd slo_medio smid_medio c pre a_medio_11 h_medio_11 x_medio_11 y_medio_11 canal rd=3e+06 cab=0
Xmedio12 vdd slo_medio smid_medio c pre a_medio_12 h_medio_12 x_medio_12 y_medio_12 canal rd=1e+12 cab=0
Vlo_alto slo_alto 0 0
Vmid_alto smid_alto 0 0
Xalto0 vdd slo_alto smid_alto c pre a_alto_0 h_alto_0 x_alto_0 y_alto_0 canal rd=30 cab=0
Xalto1 vdd slo_alto smid_alto c pre a_alto_1 h_alto_1 x_alto_1 y_alto_1 canal rd=100 cab=0
Xalto2 vdd slo_alto smid_alto c pre a_alto_2 h_alto_2 x_alto_2 y_alto_2 canal rd=300 cab=0
Xalto3 vdd slo_alto smid_alto c pre a_alto_3 h_alto_3 x_alto_3 y_alto_3 canal rd=1000 cab=0
Xalto4 vdd slo_alto smid_alto c pre a_alto_4 h_alto_4 x_alto_4 y_alto_4 canal rd=3000 cab=0
Xalto5 vdd slo_alto smid_alto c pre a_alto_5 h_alto_5 x_alto_5 y_alto_5 canal rd=10000 cab=0
Xalto6 vdd slo_alto smid_alto c pre a_alto_6 h_alto_6 x_alto_6 y_alto_6 canal rd=12906 cab=0
Xalto7 vdd slo_alto smid_alto c pre a_alto_7 h_alto_7 x_alto_7 y_alto_7 canal rd=30000 cab=0
Xalto8 vdd slo_alto smid_alto c pre a_alto_8 h_alto_8 x_alto_8 y_alto_8 canal rd=100000 cab=0
Xalto9 vdd slo_alto smid_alto c pre a_alto_9 h_alto_9 x_alto_9 y_alto_9 canal rd=300000 cab=0
Xalto10 vdd slo_alto smid_alto c pre a_alto_10 h_alto_10 x_alto_10 y_alto_10 canal rd=1e+06 cab=0
Xalto11 vdd slo_alto smid_alto c pre a_alto_11 h_alto_11 x_alto_11 y_alto_11 canal rd=3e+06 cab=0
Xalto12 vdd slo_alto smid_alto c pre a_alto_12 h_alto_12 x_alto_12 y_alto_12 canal rd=1e+12 cab=0
.control
op
echo T0 bajo 30 $&v(a_bajo_0) $&v(h_bajo_0)
echo T0 bajo 100 $&v(a_bajo_1) $&v(h_bajo_1)
echo T0 bajo 300 $&v(a_bajo_2) $&v(h_bajo_2)
echo T0 bajo 1000 $&v(a_bajo_3) $&v(h_bajo_3)
echo T0 bajo 3000 $&v(a_bajo_4) $&v(h_bajo_4)
echo T0 bajo 10000 $&v(a_bajo_5) $&v(h_bajo_5)
echo T0 bajo 12906 $&v(a_bajo_6) $&v(h_bajo_6)
echo T0 bajo 30000 $&v(a_bajo_7) $&v(h_bajo_7)
echo T0 bajo 100000 $&v(a_bajo_8) $&v(h_bajo_8)
echo T0 bajo 300000 $&v(a_bajo_9) $&v(h_bajo_9)
echo T0 bajo 1e+06 $&v(a_bajo_10) $&v(h_bajo_10)
echo T0 bajo 3e+06 $&v(a_bajo_11) $&v(h_bajo_11)
echo T0 bajo 1e+12 $&v(a_bajo_12) $&v(h_bajo_12)
echo T0 medio 30 $&v(a_medio_0) $&v(h_medio_0)
echo T0 medio 100 $&v(a_medio_1) $&v(h_medio_1)
echo T0 medio 300 $&v(a_medio_2) $&v(h_medio_2)
echo T0 medio 1000 $&v(a_medio_3) $&v(h_medio_3)
echo T0 medio 3000 $&v(a_medio_4) $&v(h_medio_4)
echo T0 medio 10000 $&v(a_medio_5) $&v(h_medio_5)
echo T0 medio 12906 $&v(a_medio_6) $&v(h_medio_6)
echo T0 medio 30000 $&v(a_medio_7) $&v(h_medio_7)
echo T0 medio 100000 $&v(a_medio_8) $&v(h_medio_8)
echo T0 medio 300000 $&v(a_medio_9) $&v(h_medio_9)
echo T0 medio 1e+06 $&v(a_medio_10) $&v(h_medio_10)
echo T0 medio 3e+06 $&v(a_medio_11) $&v(h_medio_11)
echo T0 medio 1e+12 $&v(a_medio_12) $&v(h_medio_12)
echo T0 alto 30 $&v(a_alto_0) $&v(h_alto_0)
echo T0 alto 100 $&v(a_alto_1) $&v(h_alto_1)
echo T0 alto 300 $&v(a_alto_2) $&v(h_alto_2)
echo T0 alto 1000 $&v(a_alto_3) $&v(h_alto_3)
echo T0 alto 3000 $&v(a_alto_4) $&v(h_alto_4)
echo T0 alto 10000 $&v(a_alto_5) $&v(h_alto_5)
echo T0 alto 12906 $&v(a_alto_6) $&v(h_alto_6)
echo T0 alto 30000 $&v(a_alto_7) $&v(h_alto_7)
echo T0 alto 100000 $&v(a_alto_8) $&v(h_alto_8)
echo T0 alto 300000 $&v(a_alto_9) $&v(h_alto_9)
echo T0 alto 1e+06 $&v(a_alto_10) $&v(h_alto_10)
echo T0 alto 3e+06 $&v(a_alto_11) $&v(h_alto_11)
echo T0 alto 1e+12 $&v(a_alto_12) $&v(h_alto_12)
print i(Vdd)
quit
.endc
.end
