* b05 T4: cambio de rango
.lib /foss/pdks/sky130A/libs.tech/ngspice/sky130.lib.spice tt
.include /foss/pdks/sky130A/libs.ref/sky130_fd_sc_hd/spice/sky130_fd_sc_hd.spice
.options gmin=1e-15 abstol=1e-15 reltol=1e-4
.temp 27
.subckt canal vdd slo smid c pre a h x y rd=100 cab=50f
XR1 vdd h 0 sky130_fd_pr__res_high_po_0p35 l=56
XR2 h 0 0 sky130_fd_pr__res_high_po_0p35 l=0.5
XRhi h a 0 sky130_fd_pr__res_xhigh_po_0p35 l=52
XMmid h smid m1 0 sky130_fd_pr__nfet_01v8 w=1 l=0.15
XRmid m1 a 0 sky130_fd_pr__res_xhigh_po_0p35 l=1.75
XMlo h slo a 0 sky130_fd_pr__nfet_01v8 w=5 l=0.15
Rdut a 0 r = {rd*exp(23.03*v(c))}
Cab a 0 {cab}
Cpar a 0 5f
Xc0 vdd vdd c1 0 sky130_fd_pr__nfet_01v8 w=1 l=1
Xc1 c1 c1 vb 0 sky130_fd_pr__nfet_01v8 w=1 l=1
Xc2 vb vb 0 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.15 m=16
Cf vb 0 1p
Xp x pre vdd vdd sky130_fd_pr__pfet_01v8 w=0.42 l=0.15
Xr x vb a 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.15
Xi x 0 0 vdd vdd y sky130_fd_sc_hd__inv_1
.ends
Vdd vdd 0 1.8
Vz z 0 0
Vc c 0 0
Vs s 0 pulse(0 1.8 2u 1n 1n 10u 20u)
Rg s sg 1meg
Cg sg 0 200f
X12k9_lo_crudo_0 vdd s z c z a_12k9_lo_crudo_0 h_12k9_lo_crudo_0 x_12k9_lo_crudo_0 y_12k9_lo_crudo_0 canal rd=12906 cab=0
X12k9_lo_crudo_50f vdd s z c z a_12k9_lo_crudo_50f h_12k9_lo_crudo_50f x_12k9_lo_crudo_50f y_12k9_lo_crudo_50f canal rd=12906 cab=50f
X12k9_lo_frenado_0 vdd sg z c z a_12k9_lo_frenado_0 h_12k9_lo_frenado_0 x_12k9_lo_frenado_0 y_12k9_lo_frenado_0 canal rd=12906 cab=0
X12k9_lo_frenado_50f vdd sg z c z a_12k9_lo_frenado_50f h_12k9_lo_frenado_50f x_12k9_lo_frenado_50f y_12k9_lo_frenado_50f canal rd=12906 cab=50f
X12k9_mid_crudo_0 vdd z s c z a_12k9_mid_crudo_0 h_12k9_mid_crudo_0 x_12k9_mid_crudo_0 y_12k9_mid_crudo_0 canal rd=12906 cab=0
X12k9_mid_crudo_50f vdd z s c z a_12k9_mid_crudo_50f h_12k9_mid_crudo_50f x_12k9_mid_crudo_50f y_12k9_mid_crudo_50f canal rd=12906 cab=50f
X12k9_mid_frenado_0 vdd z sg c z a_12k9_mid_frenado_0 h_12k9_mid_frenado_0 x_12k9_mid_frenado_0 y_12k9_mid_frenado_0 canal rd=12906 cab=0
X12k9_mid_frenado_50f vdd z sg c z a_12k9_mid_frenado_50f h_12k9_mid_frenado_50f x_12k9_mid_frenado_50f y_12k9_mid_frenado_50f canal rd=12906 cab=50f
X1M_lo_crudo_0 vdd s z c z a_1M_lo_crudo_0 h_1M_lo_crudo_0 x_1M_lo_crudo_0 y_1M_lo_crudo_0 canal rd=1e+06 cab=0
X1M_lo_crudo_50f vdd s z c z a_1M_lo_crudo_50f h_1M_lo_crudo_50f x_1M_lo_crudo_50f y_1M_lo_crudo_50f canal rd=1e+06 cab=50f
X1M_lo_frenado_0 vdd sg z c z a_1M_lo_frenado_0 h_1M_lo_frenado_0 x_1M_lo_frenado_0 y_1M_lo_frenado_0 canal rd=1e+06 cab=0
X1M_lo_frenado_50f vdd sg z c z a_1M_lo_frenado_50f h_1M_lo_frenado_50f x_1M_lo_frenado_50f y_1M_lo_frenado_50f canal rd=1e+06 cab=50f
X1M_mid_crudo_0 vdd z s c z a_1M_mid_crudo_0 h_1M_mid_crudo_0 x_1M_mid_crudo_0 y_1M_mid_crudo_0 canal rd=1e+06 cab=0
X1M_mid_crudo_50f vdd z s c z a_1M_mid_crudo_50f h_1M_mid_crudo_50f x_1M_mid_crudo_50f y_1M_mid_crudo_50f canal rd=1e+06 cab=50f
X1M_mid_frenado_0 vdd z sg c z a_1M_mid_frenado_0 h_1M_mid_frenado_0 x_1M_mid_frenado_0 y_1M_mid_frenado_0 canal rd=1e+06 cab=0
X1M_mid_frenado_50f vdd z sg c z a_1M_mid_frenado_50f h_1M_mid_frenado_50f x_1M_mid_frenado_50f y_1M_mid_frenado_50f canal rd=1e+06 cab=50f
Xab_lo_crudo_0 vdd s z c z a_ab_lo_crudo_0 h_ab_lo_crudo_0 x_ab_lo_crudo_0 y_ab_lo_crudo_0 canal rd=1e+12 cab=0
Xab_lo_crudo_50f vdd s z c z a_ab_lo_crudo_50f h_ab_lo_crudo_50f x_ab_lo_crudo_50f y_ab_lo_crudo_50f canal rd=1e+12 cab=50f
Xab_lo_frenado_0 vdd sg z c z a_ab_lo_frenado_0 h_ab_lo_frenado_0 x_ab_lo_frenado_0 y_ab_lo_frenado_0 canal rd=1e+12 cab=0
Xab_lo_frenado_50f vdd sg z c z a_ab_lo_frenado_50f h_ab_lo_frenado_50f x_ab_lo_frenado_50f y_ab_lo_frenado_50f canal rd=1e+12 cab=50f
Xab_mid_crudo_0 vdd z s c z a_ab_mid_crudo_0 h_ab_mid_crudo_0 x_ab_mid_crudo_0 y_ab_mid_crudo_0 canal rd=1e+12 cab=0
Xab_mid_crudo_50f vdd z s c z a_ab_mid_crudo_50f h_ab_mid_crudo_50f x_ab_mid_crudo_50f y_ab_mid_crudo_50f canal rd=1e+12 cab=50f
Xab_mid_frenado_0 vdd z sg c z a_ab_mid_frenado_0 h_ab_mid_frenado_0 x_ab_mid_frenado_0 y_ab_mid_frenado_0 canal rd=1e+12 cab=0
Xab_mid_frenado_50f vdd z sg c z a_ab_mid_frenado_50f h_ab_mid_frenado_50f x_ab_mid_frenado_50f y_ab_mid_frenado_50f canal rd=1e+12 cab=50f
.control
tran 0.2n 16u 1u
meas tran mx_12k9_lo_crudo_0 max v(a_12k9_lo_crudo_0)
meas tran mn_12k9_lo_crudo_0 min v(a_12k9_lo_crudo_0)
echo T4 R=12k9 conmuta=lo flanco=crudo cab=0 max=$&mx_12k9_lo_crudo_0 min=$&mn_12k9_lo_crudo_0
meas tran mx_12k9_lo_crudo_50f max v(a_12k9_lo_crudo_50f)
meas tran mn_12k9_lo_crudo_50f min v(a_12k9_lo_crudo_50f)
echo T4 R=12k9 conmuta=lo flanco=crudo cab=50f max=$&mx_12k9_lo_crudo_50f min=$&mn_12k9_lo_crudo_50f
meas tran mx_12k9_lo_frenado_0 max v(a_12k9_lo_frenado_0)
meas tran mn_12k9_lo_frenado_0 min v(a_12k9_lo_frenado_0)
echo T4 R=12k9 conmuta=lo flanco=frenado cab=0 max=$&mx_12k9_lo_frenado_0 min=$&mn_12k9_lo_frenado_0
meas tran mx_12k9_lo_frenado_50f max v(a_12k9_lo_frenado_50f)
meas tran mn_12k9_lo_frenado_50f min v(a_12k9_lo_frenado_50f)
echo T4 R=12k9 conmuta=lo flanco=frenado cab=50f max=$&mx_12k9_lo_frenado_50f min=$&mn_12k9_lo_frenado_50f
meas tran mx_12k9_mid_crudo_0 max v(a_12k9_mid_crudo_0)
meas tran mn_12k9_mid_crudo_0 min v(a_12k9_mid_crudo_0)
echo T4 R=12k9 conmuta=mid flanco=crudo cab=0 max=$&mx_12k9_mid_crudo_0 min=$&mn_12k9_mid_crudo_0
meas tran mx_12k9_mid_crudo_50f max v(a_12k9_mid_crudo_50f)
meas tran mn_12k9_mid_crudo_50f min v(a_12k9_mid_crudo_50f)
echo T4 R=12k9 conmuta=mid flanco=crudo cab=50f max=$&mx_12k9_mid_crudo_50f min=$&mn_12k9_mid_crudo_50f
meas tran mx_12k9_mid_frenado_0 max v(a_12k9_mid_frenado_0)
meas tran mn_12k9_mid_frenado_0 min v(a_12k9_mid_frenado_0)
echo T4 R=12k9 conmuta=mid flanco=frenado cab=0 max=$&mx_12k9_mid_frenado_0 min=$&mn_12k9_mid_frenado_0
meas tran mx_12k9_mid_frenado_50f max v(a_12k9_mid_frenado_50f)
meas tran mn_12k9_mid_frenado_50f min v(a_12k9_mid_frenado_50f)
echo T4 R=12k9 conmuta=mid flanco=frenado cab=50f max=$&mx_12k9_mid_frenado_50f min=$&mn_12k9_mid_frenado_50f
meas tran mx_1M_lo_crudo_0 max v(a_1M_lo_crudo_0)
meas tran mn_1M_lo_crudo_0 min v(a_1M_lo_crudo_0)
echo T4 R=1M conmuta=lo flanco=crudo cab=0 max=$&mx_1M_lo_crudo_0 min=$&mn_1M_lo_crudo_0
meas tran mx_1M_lo_crudo_50f max v(a_1M_lo_crudo_50f)
meas tran mn_1M_lo_crudo_50f min v(a_1M_lo_crudo_50f)
echo T4 R=1M conmuta=lo flanco=crudo cab=50f max=$&mx_1M_lo_crudo_50f min=$&mn_1M_lo_crudo_50f
meas tran mx_1M_lo_frenado_0 max v(a_1M_lo_frenado_0)
meas tran mn_1M_lo_frenado_0 min v(a_1M_lo_frenado_0)
echo T4 R=1M conmuta=lo flanco=frenado cab=0 max=$&mx_1M_lo_frenado_0 min=$&mn_1M_lo_frenado_0
meas tran mx_1M_lo_frenado_50f max v(a_1M_lo_frenado_50f)
meas tran mn_1M_lo_frenado_50f min v(a_1M_lo_frenado_50f)
echo T4 R=1M conmuta=lo flanco=frenado cab=50f max=$&mx_1M_lo_frenado_50f min=$&mn_1M_lo_frenado_50f
meas tran mx_1M_mid_crudo_0 max v(a_1M_mid_crudo_0)
meas tran mn_1M_mid_crudo_0 min v(a_1M_mid_crudo_0)
echo T4 R=1M conmuta=mid flanco=crudo cab=0 max=$&mx_1M_mid_crudo_0 min=$&mn_1M_mid_crudo_0
meas tran mx_1M_mid_crudo_50f max v(a_1M_mid_crudo_50f)
meas tran mn_1M_mid_crudo_50f min v(a_1M_mid_crudo_50f)
echo T4 R=1M conmuta=mid flanco=crudo cab=50f max=$&mx_1M_mid_crudo_50f min=$&mn_1M_mid_crudo_50f
meas tran mx_1M_mid_frenado_0 max v(a_1M_mid_frenado_0)
meas tran mn_1M_mid_frenado_0 min v(a_1M_mid_frenado_0)
echo T4 R=1M conmuta=mid flanco=frenado cab=0 max=$&mx_1M_mid_frenado_0 min=$&mn_1M_mid_frenado_0
meas tran mx_1M_mid_frenado_50f max v(a_1M_mid_frenado_50f)
meas tran mn_1M_mid_frenado_50f min v(a_1M_mid_frenado_50f)
echo T4 R=1M conmuta=mid flanco=frenado cab=50f max=$&mx_1M_mid_frenado_50f min=$&mn_1M_mid_frenado_50f
meas tran mx_ab_lo_crudo_0 max v(a_ab_lo_crudo_0)
meas tran mn_ab_lo_crudo_0 min v(a_ab_lo_crudo_0)
echo T4 R=ab conmuta=lo flanco=crudo cab=0 max=$&mx_ab_lo_crudo_0 min=$&mn_ab_lo_crudo_0
meas tran mx_ab_lo_crudo_50f max v(a_ab_lo_crudo_50f)
meas tran mn_ab_lo_crudo_50f min v(a_ab_lo_crudo_50f)
echo T4 R=ab conmuta=lo flanco=crudo cab=50f max=$&mx_ab_lo_crudo_50f min=$&mn_ab_lo_crudo_50f
meas tran mx_ab_lo_frenado_0 max v(a_ab_lo_frenado_0)
meas tran mn_ab_lo_frenado_0 min v(a_ab_lo_frenado_0)
echo T4 R=ab conmuta=lo flanco=frenado cab=0 max=$&mx_ab_lo_frenado_0 min=$&mn_ab_lo_frenado_0
meas tran mx_ab_lo_frenado_50f max v(a_ab_lo_frenado_50f)
meas tran mn_ab_lo_frenado_50f min v(a_ab_lo_frenado_50f)
echo T4 R=ab conmuta=lo flanco=frenado cab=50f max=$&mx_ab_lo_frenado_50f min=$&mn_ab_lo_frenado_50f
meas tran mx_ab_mid_crudo_0 max v(a_ab_mid_crudo_0)
meas tran mn_ab_mid_crudo_0 min v(a_ab_mid_crudo_0)
echo T4 R=ab conmuta=mid flanco=crudo cab=0 max=$&mx_ab_mid_crudo_0 min=$&mn_ab_mid_crudo_0
meas tran mx_ab_mid_crudo_50f max v(a_ab_mid_crudo_50f)
meas tran mn_ab_mid_crudo_50f min v(a_ab_mid_crudo_50f)
echo T4 R=ab conmuta=mid flanco=crudo cab=50f max=$&mx_ab_mid_crudo_50f min=$&mn_ab_mid_crudo_50f
meas tran mx_ab_mid_frenado_0 max v(a_ab_mid_frenado_0)
meas tran mn_ab_mid_frenado_0 min v(a_ab_mid_frenado_0)
echo T4 R=ab conmuta=mid flanco=frenado cab=0 max=$&mx_ab_mid_frenado_0 min=$&mn_ab_mid_frenado_0
meas tran mx_ab_mid_frenado_50f max v(a_ab_mid_frenado_50f)
meas tran mn_ab_mid_frenado_50f min v(a_ab_mid_frenado_50f)
echo T4 R=ab conmuta=mid flanco=frenado cab=50f max=$&mx_ab_mid_frenado_50f min=$&mn_ab_mid_frenado_50f
set wr_singlescale
set wr_vecnames
wrdata /w/t4_trazas.dat v(a_ab_lo_crudo_0) v(a_ab_lo_crudo_50f) v(a_ab_lo_frenado_50f) v(a_ab_lo_frenado_0)
quit
.endc
.end
