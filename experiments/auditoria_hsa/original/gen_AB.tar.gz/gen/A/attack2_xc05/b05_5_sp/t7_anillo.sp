* b05 T7: anillo con resistencia serie; tensión sobre el dispositivo
.lib /foss/pdks/sky130A/libs.tech/ngspice/sky130.lib.spice tt
.include /foss/pdks/sky130A/libs.ref/sky130_fd_sc_hd/spice/sky130_fd_sc_hd.spice
.options gmin=1e-15 abstol=1e-15 reltol=1e-4
.temp 27
.subckt canal vdd slo smid c pre a h x y rd=100 cab=50f
XR1 vdd h 0 sky130_fd_pr__res_high_po_0p35 l=56
XR2 h 0 0 sky130_fd_pr__res_high_po_0p35 l=0.5
XRhi h a 0 sky130_fd_pr__res_xhigh_po_0p35 l=52
XMmid h smid m1 0 sky130_fd_pr__nfet_01v8 w=1 l=0.15
XRmid m1 a 0 sky130_fd_pr__res_xhigh_po_0p35 l=1.75
XMlo h slo a 0 sky130_fd_pr__nfet_01v8 w=5 l=0.15
Rdut a 0 r = {rd*exp(23.03*v(c))}
Cab a 0 {cab}
Cpar a 0 5f
Xc0 vdd vdd c1 0 sky130_fd_pr__nfet_01v8 w=1 l=1
Xc1 c1 c1 vb 0 sky130_fd_pr__nfet_01v8 w=1 l=1
Xc2 vb vb 0 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.15 m=16
Cf vb 0 1p
Xp x pre vdd vdd sky130_fd_pr__pfet_01v8 w=0.42 l=0.15
Xr x vb a 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.15
Xi x 0 0 vdd vdd y sky130_fd_sc_hd__inv_1
.ends
.subckt anillo en vdd m nb rser=100k rd=12906
Xn0 en fb 0 0 vdd vdd s1 sky130_fd_sc_hd__nand2_1
Xi1 s1 0 0 vdd vdd s2 sky130_fd_sc_hd__inv_1
Xeb s2 0 0 0 vdd vdd na sky130_fd_sc_hd__ebufn_1
Rs na m {rser}
Rd m nb {rd}
Xl0 nb 0 0 vdd vdd q0 sky130_fd_sc_hd__inv_1
Xl1 nb 0 0 vdd vdd q1 sky130_fd_sc_hd__inv_1
Xl2 nb 0 0 vdd vdd q2 sky130_fd_sc_hd__inv_1
Xl3 nb 0 0 vdd vdd q3 sky130_fd_sc_hd__inv_1
Xl4 nb 0 0 vdd vdd q4 sky130_fd_sc_hd__inv_1
Xl5 nb 0 0 vdd vdd q5 sky130_fd_sc_hd__inv_1
Xl6 nb 0 0 vdd vdd q6 sky130_fd_sc_hd__inv_1
Xl7 nb 0 0 vdd vdd q7 sky130_fd_sc_hd__inv_1
Xl8 nb 0 0 vdd vdd q8 sky130_fd_sc_hd__inv_1
Xl9 nb 0 0 vdd vdd q9 sky130_fd_sc_hd__inv_1
Xl10 nb 0 0 vdd vdd q10 sky130_fd_sc_hd__inv_1
Xl11 nb 0 0 vdd vdd q11 sky130_fd_sc_hd__inv_1
Xl12 nb 0 0 vdd vdd q12 sky130_fd_sc_hd__inv_1
Xl13 nb 0 0 vdd vdd q13 sky130_fd_sc_hd__inv_1
Xl14 nb 0 0 vdd vdd q14 sky130_fd_sc_hd__inv_1
Xl15 nb 0 0 vdd vdd q15 sky130_fd_sc_hd__inv_1
Xl16 nb 0 0 vdd vdd q16 sky130_fd_sc_hd__inv_1
Xl17 nb 0 0 vdd vdd q17 sky130_fd_sc_hd__inv_1
Xl18 nb 0 0 vdd vdd q18 sky130_fd_sc_hd__inv_1
Xl19 nb 0 0 vdd vdd q19 sky130_fd_sc_hd__inv_1
Xl20 nb 0 0 vdd vdd q20 sky130_fd_sc_hd__inv_1
Xl21 nb 0 0 vdd vdd q21 sky130_fd_sc_hd__inv_1
Xl22 nb 0 0 vdd vdd q22 sky130_fd_sc_hd__inv_1
Xl23 nb 0 0 vdd vdd q23 sky130_fd_sc_hd__inv_1
Xl24 nb 0 0 vdd vdd q24 sky130_fd_sc_hd__inv_1
Xl25 nb 0 0 vdd vdd q25 sky130_fd_sc_hd__inv_1
Xl26 nb 0 0 vdd vdd q26 sky130_fd_sc_hd__inv_1
Xl27 nb 0 0 vdd vdd q27 sky130_fd_sc_hd__inv_1
Xl28 nb 0 0 vdd vdd q28 sky130_fd_sc_hd__inv_1
Xl29 nb 0 0 vdd vdd q29 sky130_fd_sc_hd__inv_1
Xl30 nb 0 0 vdd vdd q30 sky130_fd_sc_hd__inv_1
Xl31 nb 0 0 vdd vdd q31 sky130_fd_sc_hd__inv_1
Xc0 nb 0 0 vdd vdd c0 sky130_fd_sc_hd__inv_1
Xc1 c0 0 0 vdd vdd c1 sky130_fd_sc_hd__inv_1
Xc2 c1 0 0 vdd vdd c2 sky130_fd_sc_hd__inv_1
Xc3 c2 0 0 vdd vdd c3 sky130_fd_sc_hd__inv_1
Xc4 c3 0 0 vdd vdd c4 sky130_fd_sc_hd__inv_1
Xc5 c4 0 0 vdd vdd c5 sky130_fd_sc_hd__inv_1
Xc6 c5 0 0 vdd vdd c6 sky130_fd_sc_hd__inv_1
Xc7 c6 0 0 vdd vdd c7 sky130_fd_sc_hd__inv_1
Xc8 c7 0 0 vdd vdd c8 sky130_fd_sc_hd__inv_1
Xc9 c8 0 0 vdd vdd c9 sky130_fd_sc_hd__inv_1
Xc10 c9 0 0 vdd vdd fb sky130_fd_sc_hd__inv_1
.ends
Vdd vdd 0 1.8
Ven en 0 pwl(0 0 1n 0 1.1n 1.8)
X0_100 en vdd m_0_100 nb_0_100 anillo rser=1 rd=100
X0_12k9 en vdd m_0_12k9 nb_0_12k9 anillo rser=1 rd=12906
X0_1M en vdd m_0_1M nb_0_1M anillo rser=1 rd=1e+06
X30k_100 en vdd m_30k_100 nb_30k_100 anillo rser=30k rd=100
X30k_12k9 en vdd m_30k_12k9 nb_30k_12k9 anillo rser=30k rd=12906
X30k_1M en vdd m_30k_1M nb_30k_1M anillo rser=30k rd=1e+06
X100k_100 en vdd m_100k_100 nb_100k_100 anillo rser=100k rd=100
X100k_12k9 en vdd m_100k_12k9 nb_100k_12k9 anillo rser=100k rd=12906
X100k_1M en vdd m_100k_1M nb_100k_1M anillo rser=100k rd=1e+06
X1meg_100 en vdd m_1meg_100 nb_1meg_100 anillo rser=1meg rd=100
X1meg_12k9 en vdd m_1meg_12k9 nb_1meg_12k9 anillo rser=1meg rd=12906
X1meg_1M en vdd m_1meg_1M nb_1meg_1M anillo rser=1meg rd=1e+06
.control
tran 20p 400n
let d_0_100 = v(m_0_100)-v(nb_0_100)
meas tran mx_0_100 max d_0_100
meas tran mn_0_100 min d_0_100
echo T7 Rser=0 R=100 max=$&mx_0_100 min=$&mn_0_100
let d_0_12k9 = v(m_0_12k9)-v(nb_0_12k9)
meas tran mx_0_12k9 max d_0_12k9
meas tran mn_0_12k9 min d_0_12k9
echo T7 Rser=0 R=12k9 max=$&mx_0_12k9 min=$&mn_0_12k9
let d_0_1M = v(m_0_1M)-v(nb_0_1M)
meas tran mx_0_1M max d_0_1M
meas tran mn_0_1M min d_0_1M
echo T7 Rser=0 R=1M max=$&mx_0_1M min=$&mn_0_1M
let d_30k_100 = v(m_30k_100)-v(nb_30k_100)
meas tran mx_30k_100 max d_30k_100
meas tran mn_30k_100 min d_30k_100
echo T7 Rser=30k R=100 max=$&mx_30k_100 min=$&mn_30k_100
let d_30k_12k9 = v(m_30k_12k9)-v(nb_30k_12k9)
meas tran mx_30k_12k9 max d_30k_12k9
meas tran mn_30k_12k9 min d_30k_12k9
echo T7 Rser=30k R=12k9 max=$&mx_30k_12k9 min=$&mn_30k_12k9
let d_30k_1M = v(m_30k_1M)-v(nb_30k_1M)
meas tran mx_30k_1M max d_30k_1M
meas tran mn_30k_1M min d_30k_1M
echo T7 Rser=30k R=1M max=$&mx_30k_1M min=$&mn_30k_1M
let d_100k_100 = v(m_100k_100)-v(nb_100k_100)
meas tran mx_100k_100 max d_100k_100
meas tran mn_100k_100 min d_100k_100
echo T7 Rser=100k R=100 max=$&mx_100k_100 min=$&mn_100k_100
let d_100k_12k9 = v(m_100k_12k9)-v(nb_100k_12k9)
meas tran mx_100k_12k9 max d_100k_12k9
meas tran mn_100k_12k9 min d_100k_12k9
echo T7 Rser=100k R=12k9 max=$&mx_100k_12k9 min=$&mn_100k_12k9
let d_100k_1M = v(m_100k_1M)-v(nb_100k_1M)
meas tran mx_100k_1M max d_100k_1M
meas tran mn_100k_1M min d_100k_1M
echo T7 Rser=100k R=1M max=$&mx_100k_1M min=$&mn_100k_1M
let d_1meg_100 = v(m_1meg_100)-v(nb_1meg_100)
meas tran mx_1meg_100 max d_1meg_100
meas tran mn_1meg_100 min d_1meg_100
echo T7 Rser=1meg R=100 max=$&mx_1meg_100 min=$&mn_1meg_100
let d_1meg_12k9 = v(m_1meg_12k9)-v(nb_1meg_12k9)
meas tran mx_1meg_12k9 max d_1meg_12k9
meas tran mn_1meg_12k9 min d_1meg_12k9
echo T7 Rser=1meg R=12k9 max=$&mx_1meg_12k9 min=$&mn_1meg_12k9
let d_1meg_1M = v(m_1meg_1M)-v(nb_1meg_1M)
meas tran mx_1meg_1M max d_1meg_1M
meas tran mn_1meg_1M min d_1meg_1M
echo T7 Rser=1meg R=1M max=$&mx_1meg_1M min=$&mn_1meg_1M
quit
.endc
.end
