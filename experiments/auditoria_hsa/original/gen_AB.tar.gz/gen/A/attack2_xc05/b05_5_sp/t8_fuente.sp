* b05 T8: fuente de corriente sin limitar
.lib /foss/pdks/sky130A/libs.tech/ngspice/sky130.lib.spice tt
.include /foss/pdks/sky130A/libs.ref/sky130_fd_sc_hd/spice/sky130_fd_sc_hd.spice
.options gmin=1e-15 abstol=1e-15 reltol=1e-4
.temp 27
.subckt canal vdd slo smid c pre a h x y rd=100 cab=50f
XR1 vdd h 0 sky130_fd_pr__res_high_po_0p35 l=56
XR2 h 0 0 sky130_fd_pr__res_high_po_0p35 l=0.5
XRhi h a 0 sky130_fd_pr__res_xhigh_po_0p35 l=52
XMmid h smid m1 0 sky130_fd_pr__nfet_01v8 w=1 l=0.15
XRmid m1 a 0 sky130_fd_pr__res_xhigh_po_0p35 l=1.75
XMlo h slo a 0 sky130_fd_pr__nfet_01v8 w=5 l=0.15
Rdut a 0 r = {rd*exp(23.03*v(c))}
Cab a 0 {cab}
Cpar a 0 5f
Xc0 vdd vdd c1 0 sky130_fd_pr__nfet_01v8 w=1 l=1
Xc1 c1 c1 vb 0 sky130_fd_pr__nfet_01v8 w=1 l=1
Xc2 vb vb 0 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.15 m=16
Cf vb 0 1p
Xp x pre vdd vdd sky130_fd_pr__pfet_01v8 w=0.42 l=0.15
Xr x vb a 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.15
Xi x 0 0 vdd vdd y sky130_fd_sc_hd__inv_1
.ends
Vdd vdd 0 1.8
Ib bp 0 50n
Xm1 bp bp vdd vdd sky130_fd_pr__pfet_01v8 w=1 l=1
Xm2 a bp vdd vdd sky130_fd_pr__pfet_01v8 w=1 l=1
Vc c 0 pwl(0 0 1u 0 1.001u 1)
Rdut a 0 r = {100*exp(23.03*v(c))}
Cpar a 0 5f
.control
tran 1n 20u
meas tran v0 find v(a) at=0.9u
meas tran t50 when v(a)=0.05 rise=1
meas tran t100 when v(a)=0.1 rise=1
meas tran mx max v(a)
echo T8 antes=$&v0 t_50mV=$&t50 t_100mV=$&t100 max=$&mx
quit
.endc
.end
