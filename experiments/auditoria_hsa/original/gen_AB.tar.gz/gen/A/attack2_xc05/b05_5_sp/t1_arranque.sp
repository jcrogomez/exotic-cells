* b05 T1: arranque/apagado
.lib /foss/pdks/sky130A/libs.tech/ngspice/sky130.lib.spice tt
.include /foss/pdks/sky130A/libs.ref/sky130_fd_sc_hd/spice/sky130_fd_sc_hd.spice
.options gmin=1e-15 abstol=1e-15 reltol=1e-4
.temp 27
.subckt canal vdd slo smid c pre a h x y rd=100 cab=50f
XR1 vdd h 0 sky130_fd_pr__res_high_po_0p35 l=56
XR2 h 0 0 sky130_fd_pr__res_high_po_0p35 l=0.5
XRhi h a 0 sky130_fd_pr__res_xhigh_po_0p35 l=52
XMmid h smid m1 0 sky130_fd_pr__nfet_01v8 w=1 l=0.15
XRmid m1 a 0 sky130_fd_pr__res_xhigh_po_0p35 l=1.75
XMlo h slo a 0 sky130_fd_pr__nfet_01v8 w=5 l=0.15
Rdut a 0 r = {rd*exp(23.03*v(c))}
Cab a 0 {cab}
Cpar a 0 5f
Xc0 vdd vdd c1 0 sky130_fd_pr__nfet_01v8 w=1 l=1
Xc1 c1 c1 vb 0 sky130_fd_pr__nfet_01v8 w=1 l=1
Xc2 vb vb 0 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.15 m=16
Cf vb 0 1p
Xp x pre vdd vdd sky130_fd_pr__pfet_01v8 w=0.42 l=0.15
Xr x vb a 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.15
Xi x 0 0 vdd vdd y sky130_fd_sc_hd__inv_1
.ends
Vc c 0 0
Vz z 0 0
Vdd10n vdd10n 0 pwl(0 0 1n 0 1.1e-08 1.8 6.0011e-05 1.8 6.0021e-05 0)
X10n_100_v_0 vdd10n vdd10n vdd10n c z a_10n_100_v_0 h_10n_100_v_0 x_10n_100_v_0 y_10n_100_v_0 canal rd=100 cab=0
X10n_100_v_50f vdd10n vdd10n vdd10n c z a_10n_100_v_50f h_10n_100_v_50f x_10n_100_v_50f y_10n_100_v_50f canal rd=100 cab=50f
X10n_100_z_0 vdd10n z z c z a_10n_100_z_0 h_10n_100_z_0 x_10n_100_z_0 y_10n_100_z_0 canal rd=100 cab=0
X10n_100_z_50f vdd10n z z c z a_10n_100_z_50f h_10n_100_z_50f x_10n_100_z_50f y_10n_100_z_50f canal rd=100 cab=50f
X10n_12k9_v_0 vdd10n vdd10n vdd10n c z a_10n_12k9_v_0 h_10n_12k9_v_0 x_10n_12k9_v_0 y_10n_12k9_v_0 canal rd=12906 cab=0
X10n_12k9_v_50f vdd10n vdd10n vdd10n c z a_10n_12k9_v_50f h_10n_12k9_v_50f x_10n_12k9_v_50f y_10n_12k9_v_50f canal rd=12906 cab=50f
X10n_12k9_z_0 vdd10n z z c z a_10n_12k9_z_0 h_10n_12k9_z_0 x_10n_12k9_z_0 y_10n_12k9_z_0 canal rd=12906 cab=0
X10n_12k9_z_50f vdd10n z z c z a_10n_12k9_z_50f h_10n_12k9_z_50f x_10n_12k9_z_50f y_10n_12k9_z_50f canal rd=12906 cab=50f
X10n_1M_v_0 vdd10n vdd10n vdd10n c z a_10n_1M_v_0 h_10n_1M_v_0 x_10n_1M_v_0 y_10n_1M_v_0 canal rd=1e+06 cab=0
X10n_1M_v_50f vdd10n vdd10n vdd10n c z a_10n_1M_v_50f h_10n_1M_v_50f x_10n_1M_v_50f y_10n_1M_v_50f canal rd=1e+06 cab=50f
X10n_1M_z_0 vdd10n z z c z a_10n_1M_z_0 h_10n_1M_z_0 x_10n_1M_z_0 y_10n_1M_z_0 canal rd=1e+06 cab=0
X10n_1M_z_50f vdd10n z z c z a_10n_1M_z_50f h_10n_1M_z_50f x_10n_1M_z_50f y_10n_1M_z_50f canal rd=1e+06 cab=50f
X10n_ab_v_0 vdd10n vdd10n vdd10n c z a_10n_ab_v_0 h_10n_ab_v_0 x_10n_ab_v_0 y_10n_ab_v_0 canal rd=1e+12 cab=0
X10n_ab_v_50f vdd10n vdd10n vdd10n c z a_10n_ab_v_50f h_10n_ab_v_50f x_10n_ab_v_50f y_10n_ab_v_50f canal rd=1e+12 cab=50f
X10n_ab_z_0 vdd10n z z c z a_10n_ab_z_0 h_10n_ab_z_0 x_10n_ab_z_0 y_10n_ab_z_0 canal rd=1e+12 cab=0
X10n_ab_z_50f vdd10n z z c z a_10n_ab_z_50f h_10n_ab_z_50f x_10n_ab_z_50f y_10n_ab_z_50f canal rd=1e+12 cab=50f
Vdd100n vdd100n 0 pwl(0 0 1n 0 1.01e-07 1.8 6.0101e-05 1.8 6.0201e-05 0)
X100n_100_v_0 vdd100n vdd100n vdd100n c z a_100n_100_v_0 h_100n_100_v_0 x_100n_100_v_0 y_100n_100_v_0 canal rd=100 cab=0
X100n_100_v_50f vdd100n vdd100n vdd100n c z a_100n_100_v_50f h_100n_100_v_50f x_100n_100_v_50f y_100n_100_v_50f canal rd=100 cab=50f
X100n_100_z_0 vdd100n z z c z a_100n_100_z_0 h_100n_100_z_0 x_100n_100_z_0 y_100n_100_z_0 canal rd=100 cab=0
X100n_100_z_50f vdd100n z z c z a_100n_100_z_50f h_100n_100_z_50f x_100n_100_z_50f y_100n_100_z_50f canal rd=100 cab=50f
X100n_12k9_v_0 vdd100n vdd100n vdd100n c z a_100n_12k9_v_0 h_100n_12k9_v_0 x_100n_12k9_v_0 y_100n_12k9_v_0 canal rd=12906 cab=0
X100n_12k9_v_50f vdd100n vdd100n vdd100n c z a_100n_12k9_v_50f h_100n_12k9_v_50f x_100n_12k9_v_50f y_100n_12k9_v_50f canal rd=12906 cab=50f
X100n_12k9_z_0 vdd100n z z c z a_100n_12k9_z_0 h_100n_12k9_z_0 x_100n_12k9_z_0 y_100n_12k9_z_0 canal rd=12906 cab=0
X100n_12k9_z_50f vdd100n z z c z a_100n_12k9_z_50f h_100n_12k9_z_50f x_100n_12k9_z_50f y_100n_12k9_z_50f canal rd=12906 cab=50f
X100n_1M_v_0 vdd100n vdd100n vdd100n c z a_100n_1M_v_0 h_100n_1M_v_0 x_100n_1M_v_0 y_100n_1M_v_0 canal rd=1e+06 cab=0
X100n_1M_v_50f vdd100n vdd100n vdd100n c z a_100n_1M_v_50f h_100n_1M_v_50f x_100n_1M_v_50f y_100n_1M_v_50f canal rd=1e+06 cab=50f
X100n_1M_z_0 vdd100n z z c z a_100n_1M_z_0 h_100n_1M_z_0 x_100n_1M_z_0 y_100n_1M_z_0 canal rd=1e+06 cab=0
X100n_1M_z_50f vdd100n z z c z a_100n_1M_z_50f h_100n_1M_z_50f x_100n_1M_z_50f y_100n_1M_z_50f canal rd=1e+06 cab=50f
X100n_ab_v_0 vdd100n vdd100n vdd100n c z a_100n_ab_v_0 h_100n_ab_v_0 x_100n_ab_v_0 y_100n_ab_v_0 canal rd=1e+12 cab=0
X100n_ab_v_50f vdd100n vdd100n vdd100n c z a_100n_ab_v_50f h_100n_ab_v_50f x_100n_ab_v_50f y_100n_ab_v_50f canal rd=1e+12 cab=50f
X100n_ab_z_0 vdd100n z z c z a_100n_ab_z_0 h_100n_ab_z_0 x_100n_ab_z_0 y_100n_ab_z_0 canal rd=1e+12 cab=0
X100n_ab_z_50f vdd100n z z c z a_100n_ab_z_50f h_100n_ab_z_50f x_100n_ab_z_50f y_100n_ab_z_50f canal rd=1e+12 cab=50f
Vdd1u vdd1u 0 pwl(0 0 1n 0 1.001e-06 1.8 6.1001e-05 1.8 6.2001e-05 0)
X1u_100_v_0 vdd1u vdd1u vdd1u c z a_1u_100_v_0 h_1u_100_v_0 x_1u_100_v_0 y_1u_100_v_0 canal rd=100 cab=0
X1u_100_v_50f vdd1u vdd1u vdd1u c z a_1u_100_v_50f h_1u_100_v_50f x_1u_100_v_50f y_1u_100_v_50f canal rd=100 cab=50f
X1u_100_z_0 vdd1u z z c z a_1u_100_z_0 h_1u_100_z_0 x_1u_100_z_0 y_1u_100_z_0 canal rd=100 cab=0
X1u_100_z_50f vdd1u z z c z a_1u_100_z_50f h_1u_100_z_50f x_1u_100_z_50f y_1u_100_z_50f canal rd=100 cab=50f
X1u_12k9_v_0 vdd1u vdd1u vdd1u c z a_1u_12k9_v_0 h_1u_12k9_v_0 x_1u_12k9_v_0 y_1u_12k9_v_0 canal rd=12906 cab=0
X1u_12k9_v_50f vdd1u vdd1u vdd1u c z a_1u_12k9_v_50f h_1u_12k9_v_50f x_1u_12k9_v_50f y_1u_12k9_v_50f canal rd=12906 cab=50f
X1u_12k9_z_0 vdd1u z z c z a_1u_12k9_z_0 h_1u_12k9_z_0 x_1u_12k9_z_0 y_1u_12k9_z_0 canal rd=12906 cab=0
X1u_12k9_z_50f vdd1u z z c z a_1u_12k9_z_50f h_1u_12k9_z_50f x_1u_12k9_z_50f y_1u_12k9_z_50f canal rd=12906 cab=50f
X1u_1M_v_0 vdd1u vdd1u vdd1u c z a_1u_1M_v_0 h_1u_1M_v_0 x_1u_1M_v_0 y_1u_1M_v_0 canal rd=1e+06 cab=0
X1u_1M_v_50f vdd1u vdd1u vdd1u c z a_1u_1M_v_50f h_1u_1M_v_50f x_1u_1M_v_50f y_1u_1M_v_50f canal rd=1e+06 cab=50f
X1u_1M_z_0 vdd1u z z c z a_1u_1M_z_0 h_1u_1M_z_0 x_1u_1M_z_0 y_1u_1M_z_0 canal rd=1e+06 cab=0
X1u_1M_z_50f vdd1u z z c z a_1u_1M_z_50f h_1u_1M_z_50f x_1u_1M_z_50f y_1u_1M_z_50f canal rd=1e+06 cab=50f
X1u_ab_v_0 vdd1u vdd1u vdd1u c z a_1u_ab_v_0 h_1u_ab_v_0 x_1u_ab_v_0 y_1u_ab_v_0 canal rd=1e+12 cab=0
X1u_ab_v_50f vdd1u vdd1u vdd1u c z a_1u_ab_v_50f h_1u_ab_v_50f x_1u_ab_v_50f y_1u_ab_v_50f canal rd=1e+12 cab=50f
X1u_ab_z_0 vdd1u z z c z a_1u_ab_z_0 h_1u_ab_z_0 x_1u_ab_z_0 y_1u_ab_z_0 canal rd=1e+12 cab=0
X1u_ab_z_50f vdd1u z z c z a_1u_ab_z_50f h_1u_ab_z_50f x_1u_ab_z_50f y_1u_ab_z_50f canal rd=1e+12 cab=50f
Vdd10u vdd10u 0 pwl(0 0 1n 0 1.0001e-05 1.8 7.0001e-05 1.8 8.0001e-05 0)
X10u_100_v_0 vdd10u vdd10u vdd10u c z a_10u_100_v_0 h_10u_100_v_0 x_10u_100_v_0 y_10u_100_v_0 canal rd=100 cab=0
X10u_100_v_50f vdd10u vdd10u vdd10u c z a_10u_100_v_50f h_10u_100_v_50f x_10u_100_v_50f y_10u_100_v_50f canal rd=100 cab=50f
X10u_100_z_0 vdd10u z z c z a_10u_100_z_0 h_10u_100_z_0 x_10u_100_z_0 y_10u_100_z_0 canal rd=100 cab=0
X10u_100_z_50f vdd10u z z c z a_10u_100_z_50f h_10u_100_z_50f x_10u_100_z_50f y_10u_100_z_50f canal rd=100 cab=50f
X10u_12k9_v_0 vdd10u vdd10u vdd10u c z a_10u_12k9_v_0 h_10u_12k9_v_0 x_10u_12k9_v_0 y_10u_12k9_v_0 canal rd=12906 cab=0
X10u_12k9_v_50f vdd10u vdd10u vdd10u c z a_10u_12k9_v_50f h_10u_12k9_v_50f x_10u_12k9_v_50f y_10u_12k9_v_50f canal rd=12906 cab=50f
X10u_12k9_z_0 vdd10u z z c z a_10u_12k9_z_0 h_10u_12k9_z_0 x_10u_12k9_z_0 y_10u_12k9_z_0 canal rd=12906 cab=0
X10u_12k9_z_50f vdd10u z z c z a_10u_12k9_z_50f h_10u_12k9_z_50f x_10u_12k9_z_50f y_10u_12k9_z_50f canal rd=12906 cab=50f
X10u_1M_v_0 vdd10u vdd10u vdd10u c z a_10u_1M_v_0 h_10u_1M_v_0 x_10u_1M_v_0 y_10u_1M_v_0 canal rd=1e+06 cab=0
X10u_1M_v_50f vdd10u vdd10u vdd10u c z a_10u_1M_v_50f h_10u_1M_v_50f x_10u_1M_v_50f y_10u_1M_v_50f canal rd=1e+06 cab=50f
X10u_1M_z_0 vdd10u z z c z a_10u_1M_z_0 h_10u_1M_z_0 x_10u_1M_z_0 y_10u_1M_z_0 canal rd=1e+06 cab=0
X10u_1M_z_50f vdd10u z z c z a_10u_1M_z_50f h_10u_1M_z_50f x_10u_1M_z_50f y_10u_1M_z_50f canal rd=1e+06 cab=50f
X10u_ab_v_0 vdd10u vdd10u vdd10u c z a_10u_ab_v_0 h_10u_ab_v_0 x_10u_ab_v_0 y_10u_ab_v_0 canal rd=1e+12 cab=0
X10u_ab_v_50f vdd10u vdd10u vdd10u c z a_10u_ab_v_50f h_10u_ab_v_50f x_10u_ab_v_50f y_10u_ab_v_50f canal rd=1e+12 cab=50f
X10u_ab_z_0 vdd10u z z c z a_10u_ab_z_0 h_10u_ab_z_0 x_10u_ab_z_0 y_10u_ab_z_0 canal rd=1e+12 cab=0
X10u_ab_z_50f vdd10u z z c z a_10u_ab_z_50f h_10u_ab_z_50f x_10u_ab_z_50f y_10u_ab_z_50f canal rd=1e+12 cab=50f
.control
tran 1n 85u
meas tran mx_10n_100_v_0 max v(a_10n_100_v_0)
meas tran mn_10n_100_v_0 min v(a_10n_100_v_0)
echo T1 rampa=10n R=100 sel=v cab=0 max=$&mx_10n_100_v_0 min=$&mn_10n_100_v_0
meas tran mx_10n_100_v_50f max v(a_10n_100_v_50f)
meas tran mn_10n_100_v_50f min v(a_10n_100_v_50f)
echo T1 rampa=10n R=100 sel=v cab=50f max=$&mx_10n_100_v_50f min=$&mn_10n_100_v_50f
meas tran mx_10n_100_z_0 max v(a_10n_100_z_0)
meas tran mn_10n_100_z_0 min v(a_10n_100_z_0)
echo T1 rampa=10n R=100 sel=z cab=0 max=$&mx_10n_100_z_0 min=$&mn_10n_100_z_0
meas tran mx_10n_100_z_50f max v(a_10n_100_z_50f)
meas tran mn_10n_100_z_50f min v(a_10n_100_z_50f)
echo T1 rampa=10n R=100 sel=z cab=50f max=$&mx_10n_100_z_50f min=$&mn_10n_100_z_50f
meas tran mx_10n_12k9_v_0 max v(a_10n_12k9_v_0)
meas tran mn_10n_12k9_v_0 min v(a_10n_12k9_v_0)
echo T1 rampa=10n R=12k9 sel=v cab=0 max=$&mx_10n_12k9_v_0 min=$&mn_10n_12k9_v_0
meas tran mx_10n_12k9_v_50f max v(a_10n_12k9_v_50f)
meas tran mn_10n_12k9_v_50f min v(a_10n_12k9_v_50f)
echo T1 rampa=10n R=12k9 sel=v cab=50f max=$&mx_10n_12k9_v_50f min=$&mn_10n_12k9_v_50f
meas tran mx_10n_12k9_z_0 max v(a_10n_12k9_z_0)
meas tran mn_10n_12k9_z_0 min v(a_10n_12k9_z_0)
echo T1 rampa=10n R=12k9 sel=z cab=0 max=$&mx_10n_12k9_z_0 min=$&mn_10n_12k9_z_0
meas tran mx_10n_12k9_z_50f max v(a_10n_12k9_z_50f)
meas tran mn_10n_12k9_z_50f min v(a_10n_12k9_z_50f)
echo T1 rampa=10n R=12k9 sel=z cab=50f max=$&mx_10n_12k9_z_50f min=$&mn_10n_12k9_z_50f
meas tran mx_10n_1M_v_0 max v(a_10n_1M_v_0)
meas tran mn_10n_1M_v_0 min v(a_10n_1M_v_0)
echo T1 rampa=10n R=1M sel=v cab=0 max=$&mx_10n_1M_v_0 min=$&mn_10n_1M_v_0
meas tran mx_10n_1M_v_50f max v(a_10n_1M_v_50f)
meas tran mn_10n_1M_v_50f min v(a_10n_1M_v_50f)
echo T1 rampa=10n R=1M sel=v cab=50f max=$&mx_10n_1M_v_50f min=$&mn_10n_1M_v_50f
meas tran mx_10n_1M_z_0 max v(a_10n_1M_z_0)
meas tran mn_10n_1M_z_0 min v(a_10n_1M_z_0)
echo T1 rampa=10n R=1M sel=z cab=0 max=$&mx_10n_1M_z_0 min=$&mn_10n_1M_z_0
meas tran mx_10n_1M_z_50f max v(a_10n_1M_z_50f)
meas tran mn_10n_1M_z_50f min v(a_10n_1M_z_50f)
echo T1 rampa=10n R=1M sel=z cab=50f max=$&mx_10n_1M_z_50f min=$&mn_10n_1M_z_50f
meas tran mx_10n_ab_v_0 max v(a_10n_ab_v_0)
meas tran mn_10n_ab_v_0 min v(a_10n_ab_v_0)
echo T1 rampa=10n R=ab sel=v cab=0 max=$&mx_10n_ab_v_0 min=$&mn_10n_ab_v_0
meas tran mx_10n_ab_v_50f max v(a_10n_ab_v_50f)
meas tran mn_10n_ab_v_50f min v(a_10n_ab_v_50f)
echo T1 rampa=10n R=ab sel=v cab=50f max=$&mx_10n_ab_v_50f min=$&mn_10n_ab_v_50f
meas tran mx_10n_ab_z_0 max v(a_10n_ab_z_0)
meas tran mn_10n_ab_z_0 min v(a_10n_ab_z_0)
echo T1 rampa=10n R=ab sel=z cab=0 max=$&mx_10n_ab_z_0 min=$&mn_10n_ab_z_0
meas tran mx_10n_ab_z_50f max v(a_10n_ab_z_50f)
meas tran mn_10n_ab_z_50f min v(a_10n_ab_z_50f)
echo T1 rampa=10n R=ab sel=z cab=50f max=$&mx_10n_ab_z_50f min=$&mn_10n_ab_z_50f
meas tran mx_100n_100_v_0 max v(a_100n_100_v_0)
meas tran mn_100n_100_v_0 min v(a_100n_100_v_0)
echo T1 rampa=100n R=100 sel=v cab=0 max=$&mx_100n_100_v_0 min=$&mn_100n_100_v_0
meas tran mx_100n_100_v_50f max v(a_100n_100_v_50f)
meas tran mn_100n_100_v_50f min v(a_100n_100_v_50f)
echo T1 rampa=100n R=100 sel=v cab=50f max=$&mx_100n_100_v_50f min=$&mn_100n_100_v_50f
meas tran mx_100n_100_z_0 max v(a_100n_100_z_0)
meas tran mn_100n_100_z_0 min v(a_100n_100_z_0)
echo T1 rampa=100n R=100 sel=z cab=0 max=$&mx_100n_100_z_0 min=$&mn_100n_100_z_0
meas tran mx_100n_100_z_50f max v(a_100n_100_z_50f)
meas tran mn_100n_100_z_50f min v(a_100n_100_z_50f)
echo T1 rampa=100n R=100 sel=z cab=50f max=$&mx_100n_100_z_50f min=$&mn_100n_100_z_50f
meas tran mx_100n_12k9_v_0 max v(a_100n_12k9_v_0)
meas tran mn_100n_12k9_v_0 min v(a_100n_12k9_v_0)
echo T1 rampa=100n R=12k9 sel=v cab=0 max=$&mx_100n_12k9_v_0 min=$&mn_100n_12k9_v_0
meas tran mx_100n_12k9_v_50f max v(a_100n_12k9_v_50f)
meas tran mn_100n_12k9_v_50f min v(a_100n_12k9_v_50f)
echo T1 rampa=100n R=12k9 sel=v cab=50f max=$&mx_100n_12k9_v_50f min=$&mn_100n_12k9_v_50f
meas tran mx_100n_12k9_z_0 max v(a_100n_12k9_z_0)
meas tran mn_100n_12k9_z_0 min v(a_100n_12k9_z_0)
echo T1 rampa=100n R=12k9 sel=z cab=0 max=$&mx_100n_12k9_z_0 min=$&mn_100n_12k9_z_0
meas tran mx_100n_12k9_z_50f max v(a_100n_12k9_z_50f)
meas tran mn_100n_12k9_z_50f min v(a_100n_12k9_z_50f)
echo T1 rampa=100n R=12k9 sel=z cab=50f max=$&mx_100n_12k9_z_50f min=$&mn_100n_12k9_z_50f
meas tran mx_100n_1M_v_0 max v(a_100n_1M_v_0)
meas tran mn_100n_1M_v_0 min v(a_100n_1M_v_0)
echo T1 rampa=100n R=1M sel=v cab=0 max=$&mx_100n_1M_v_0 min=$&mn_100n_1M_v_0
meas tran mx_100n_1M_v_50f max v(a_100n_1M_v_50f)
meas tran mn_100n_1M_v_50f min v(a_100n_1M_v_50f)
echo T1 rampa=100n R=1M sel=v cab=50f max=$&mx_100n_1M_v_50f min=$&mn_100n_1M_v_50f
meas tran mx_100n_1M_z_0 max v(a_100n_1M_z_0)
meas tran mn_100n_1M_z_0 min v(a_100n_1M_z_0)
echo T1 rampa=100n R=1M sel=z cab=0 max=$&mx_100n_1M_z_0 min=$&mn_100n_1M_z_0
meas tran mx_100n_1M_z_50f max v(a_100n_1M_z_50f)
meas tran mn_100n_1M_z_50f min v(a_100n_1M_z_50f)
echo T1 rampa=100n R=1M sel=z cab=50f max=$&mx_100n_1M_z_50f min=$&mn_100n_1M_z_50f
meas tran mx_100n_ab_v_0 max v(a_100n_ab_v_0)
meas tran mn_100n_ab_v_0 min v(a_100n_ab_v_0)
echo T1 rampa=100n R=ab sel=v cab=0 max=$&mx_100n_ab_v_0 min=$&mn_100n_ab_v_0
meas tran mx_100n_ab_v_50f max v(a_100n_ab_v_50f)
meas tran mn_100n_ab_v_50f min v(a_100n_ab_v_50f)
echo T1 rampa=100n R=ab sel=v cab=50f max=$&mx_100n_ab_v_50f min=$&mn_100n_ab_v_50f
meas tran mx_100n_ab_z_0 max v(a_100n_ab_z_0)
meas tran mn_100n_ab_z_0 min v(a_100n_ab_z_0)
echo T1 rampa=100n R=ab sel=z cab=0 max=$&mx_100n_ab_z_0 min=$&mn_100n_ab_z_0
meas tran mx_100n_ab_z_50f max v(a_100n_ab_z_50f)
meas tran mn_100n_ab_z_50f min v(a_100n_ab_z_50f)
echo T1 rampa=100n R=ab sel=z cab=50f max=$&mx_100n_ab_z_50f min=$&mn_100n_ab_z_50f
meas tran mx_1u_100_v_0 max v(a_1u_100_v_0)
meas tran mn_1u_100_v_0 min v(a_1u_100_v_0)
echo T1 rampa=1u R=100 sel=v cab=0 max=$&mx_1u_100_v_0 min=$&mn_1u_100_v_0
meas tran mx_1u_100_v_50f max v(a_1u_100_v_50f)
meas tran mn_1u_100_v_50f min v(a_1u_100_v_50f)
echo T1 rampa=1u R=100 sel=v cab=50f max=$&mx_1u_100_v_50f min=$&mn_1u_100_v_50f
meas tran mx_1u_100_z_0 max v(a_1u_100_z_0)
meas tran mn_1u_100_z_0 min v(a_1u_100_z_0)
echo T1 rampa=1u R=100 sel=z cab=0 max=$&mx_1u_100_z_0 min=$&mn_1u_100_z_0
meas tran mx_1u_100_z_50f max v(a_1u_100_z_50f)
meas tran mn_1u_100_z_50f min v(a_1u_100_z_50f)
echo T1 rampa=1u R=100 sel=z cab=50f max=$&mx_1u_100_z_50f min=$&mn_1u_100_z_50f
meas tran mx_1u_12k9_v_0 max v(a_1u_12k9_v_0)
meas tran mn_1u_12k9_v_0 min v(a_1u_12k9_v_0)
echo T1 rampa=1u R=12k9 sel=v cab=0 max=$&mx_1u_12k9_v_0 min=$&mn_1u_12k9_v_0
meas tran mx_1u_12k9_v_50f max v(a_1u_12k9_v_50f)
meas tran mn_1u_12k9_v_50f min v(a_1u_12k9_v_50f)
echo T1 rampa=1u R=12k9 sel=v cab=50f max=$&mx_1u_12k9_v_50f min=$&mn_1u_12k9_v_50f
meas tran mx_1u_12k9_z_0 max v(a_1u_12k9_z_0)
meas tran mn_1u_12k9_z_0 min v(a_1u_12k9_z_0)
echo T1 rampa=1u R=12k9 sel=z cab=0 max=$&mx_1u_12k9_z_0 min=$&mn_1u_12k9_z_0
meas tran mx_1u_12k9_z_50f max v(a_1u_12k9_z_50f)
meas tran mn_1u_12k9_z_50f min v(a_1u_12k9_z_50f)
echo T1 rampa=1u R=12k9 sel=z cab=50f max=$&mx_1u_12k9_z_50f min=$&mn_1u_12k9_z_50f
meas tran mx_1u_1M_v_0 max v(a_1u_1M_v_0)
meas tran mn_1u_1M_v_0 min v(a_1u_1M_v_0)
echo T1 rampa=1u R=1M sel=v cab=0 max=$&mx_1u_1M_v_0 min=$&mn_1u_1M_v_0
meas tran mx_1u_1M_v_50f max v(a_1u_1M_v_50f)
meas tran mn_1u_1M_v_50f min v(a_1u_1M_v_50f)
echo T1 rampa=1u R=1M sel=v cab=50f max=$&mx_1u_1M_v_50f min=$&mn_1u_1M_v_50f
meas tran mx_1u_1M_z_0 max v(a_1u_1M_z_0)
meas tran mn_1u_1M_z_0 min v(a_1u_1M_z_0)
echo T1 rampa=1u R=1M sel=z cab=0 max=$&mx_1u_1M_z_0 min=$&mn_1u_1M_z_0
meas tran mx_1u_1M_z_50f max v(a_1u_1M_z_50f)
meas tran mn_1u_1M_z_50f min v(a_1u_1M_z_50f)
echo T1 rampa=1u R=1M sel=z cab=50f max=$&mx_1u_1M_z_50f min=$&mn_1u_1M_z_50f
meas tran mx_1u_ab_v_0 max v(a_1u_ab_v_0)
meas tran mn_1u_ab_v_0 min v(a_1u_ab_v_0)
echo T1 rampa=1u R=ab sel=v cab=0 max=$&mx_1u_ab_v_0 min=$&mn_1u_ab_v_0
meas tran mx_1u_ab_v_50f max v(a_1u_ab_v_50f)
meas tran mn_1u_ab_v_50f min v(a_1u_ab_v_50f)
echo T1 rampa=1u R=ab sel=v cab=50f max=$&mx_1u_ab_v_50f min=$&mn_1u_ab_v_50f
meas tran mx_1u_ab_z_0 max v(a_1u_ab_z_0)
meas tran mn_1u_ab_z_0 min v(a_1u_ab_z_0)
echo T1 rampa=1u R=ab sel=z cab=0 max=$&mx_1u_ab_z_0 min=$&mn_1u_ab_z_0
meas tran mx_1u_ab_z_50f max v(a_1u_ab_z_50f)
meas tran mn_1u_ab_z_50f min v(a_1u_ab_z_50f)
echo T1 rampa=1u R=ab sel=z cab=50f max=$&mx_1u_ab_z_50f min=$&mn_1u_ab_z_50f
meas tran mx_10u_100_v_0 max v(a_10u_100_v_0)
meas tran mn_10u_100_v_0 min v(a_10u_100_v_0)
echo T1 rampa=10u R=100 sel=v cab=0 max=$&mx_10u_100_v_0 min=$&mn_10u_100_v_0
meas tran mx_10u_100_v_50f max v(a_10u_100_v_50f)
meas tran mn_10u_100_v_50f min v(a_10u_100_v_50f)
echo T1 rampa=10u R=100 sel=v cab=50f max=$&mx_10u_100_v_50f min=$&mn_10u_100_v_50f
meas tran mx_10u_100_z_0 max v(a_10u_100_z_0)
meas tran mn_10u_100_z_0 min v(a_10u_100_z_0)
echo T1 rampa=10u R=100 sel=z cab=0 max=$&mx_10u_100_z_0 min=$&mn_10u_100_z_0
meas tran mx_10u_100_z_50f max v(a_10u_100_z_50f)
meas tran mn_10u_100_z_50f min v(a_10u_100_z_50f)
echo T1 rampa=10u R=100 sel=z cab=50f max=$&mx_10u_100_z_50f min=$&mn_10u_100_z_50f
meas tran mx_10u_12k9_v_0 max v(a_10u_12k9_v_0)
meas tran mn_10u_12k9_v_0 min v(a_10u_12k9_v_0)
echo T1 rampa=10u R=12k9 sel=v cab=0 max=$&mx_10u_12k9_v_0 min=$&mn_10u_12k9_v_0
meas tran mx_10u_12k9_v_50f max v(a_10u_12k9_v_50f)
meas tran mn_10u_12k9_v_50f min v(a_10u_12k9_v_50f)
echo T1 rampa=10u R=12k9 sel=v cab=50f max=$&mx_10u_12k9_v_50f min=$&mn_10u_12k9_v_50f
meas tran mx_10u_12k9_z_0 max v(a_10u_12k9_z_0)
meas tran mn_10u_12k9_z_0 min v(a_10u_12k9_z_0)
echo T1 rampa=10u R=12k9 sel=z cab=0 max=$&mx_10u_12k9_z_0 min=$&mn_10u_12k9_z_0
meas tran mx_10u_12k9_z_50f max v(a_10u_12k9_z_50f)
meas tran mn_10u_12k9_z_50f min v(a_10u_12k9_z_50f)
echo T1 rampa=10u R=12k9 sel=z cab=50f max=$&mx_10u_12k9_z_50f min=$&mn_10u_12k9_z_50f
meas tran mx_10u_1M_v_0 max v(a_10u_1M_v_0)
meas tran mn_10u_1M_v_0 min v(a_10u_1M_v_0)
echo T1 rampa=10u R=1M sel=v cab=0 max=$&mx_10u_1M_v_0 min=$&mn_10u_1M_v_0
meas tran mx_10u_1M_v_50f max v(a_10u_1M_v_50f)
meas tran mn_10u_1M_v_50f min v(a_10u_1M_v_50f)
echo T1 rampa=10u R=1M sel=v cab=50f max=$&mx_10u_1M_v_50f min=$&mn_10u_1M_v_50f
meas tran mx_10u_1M_z_0 max v(a_10u_1M_z_0)
meas tran mn_10u_1M_z_0 min v(a_10u_1M_z_0)
echo T1 rampa=10u R=1M sel=z cab=0 max=$&mx_10u_1M_z_0 min=$&mn_10u_1M_z_0
meas tran mx_10u_1M_z_50f max v(a_10u_1M_z_50f)
meas tran mn_10u_1M_z_50f min v(a_10u_1M_z_50f)
echo T1 rampa=10u R=1M sel=z cab=50f max=$&mx_10u_1M_z_50f min=$&mn_10u_1M_z_50f
meas tran mx_10u_ab_v_0 max v(a_10u_ab_v_0)
meas tran mn_10u_ab_v_0 min v(a_10u_ab_v_0)
echo T1 rampa=10u R=ab sel=v cab=0 max=$&mx_10u_ab_v_0 min=$&mn_10u_ab_v_0
meas tran mx_10u_ab_v_50f max v(a_10u_ab_v_50f)
meas tran mn_10u_ab_v_50f min v(a_10u_ab_v_50f)
echo T1 rampa=10u R=ab sel=v cab=50f max=$&mx_10u_ab_v_50f min=$&mn_10u_ab_v_50f
meas tran mx_10u_ab_z_0 max v(a_10u_ab_z_0)
meas tran mn_10u_ab_z_0 min v(a_10u_ab_z_0)
echo T1 rampa=10u R=ab sel=z cab=0 max=$&mx_10u_ab_z_0 min=$&mn_10u_ab_z_0
meas tran mx_10u_ab_z_50f max v(a_10u_ab_z_50f)
meas tran mn_10u_ab_z_50f min v(a_10u_ab_z_50f)
echo T1 rampa=10u R=ab sel=z cab=50f max=$&mx_10u_ab_z_50f min=$&mn_10u_ab_z_50f
quit
.endc
.end
