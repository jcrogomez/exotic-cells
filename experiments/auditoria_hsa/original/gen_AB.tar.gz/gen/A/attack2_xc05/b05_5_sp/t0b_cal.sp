* b05 T0b: tiempo de conversión frente a V(A)
.lib /foss/pdks/sky130A/libs.tech/ngspice/sky130.lib.spice tt
.include /foss/pdks/sky130A/libs.ref/sky130_fd_sc_hd/spice/sky130_fd_sc_hd.spice
.options gmin=1e-15 abstol=1e-15 reltol=1e-4
.temp 27
.subckt canal vdd slo smid c pre a h x y rd=100 cab=50f
XR1 vdd h 0 sky130_fd_pr__res_high_po_0p35 l=56
XR2 h 0 0 sky130_fd_pr__res_high_po_0p35 l=0.5
XRhi h a 0 sky130_fd_pr__res_xhigh_po_0p35 l=52
XMmid h smid m1 0 sky130_fd_pr__nfet_01v8 w=1 l=0.15
XRmid m1 a 0 sky130_fd_pr__res_xhigh_po_0p35 l=1.75
XMlo h slo a 0 sky130_fd_pr__nfet_01v8 w=5 l=0.15
Rdut a 0 r = {rd*exp(23.03*v(c))}
Cab a 0 {cab}
Cpar a 0 5f
Xc0 vdd vdd c1 0 sky130_fd_pr__nfet_01v8 w=1 l=1
Xc1 c1 c1 vb 0 sky130_fd_pr__nfet_01v8 w=1 l=1
Xc2 vb vb 0 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.15 m=16
Cf vb 0 1p
Xp x pre vdd vdd sky130_fd_pr__pfet_01v8 w=0.42 l=0.15
Xr x vb a 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.15
Xi x 0 0 vdd vdd y sky130_fd_sc_hd__inv_1
.ends
Vdd vdd 0 1.8
Vc c 0 0
Vpre pre 0 pulse(0 1.8 1u 1n 1n 1 2)
Vlo slo 0 0
Vmid smid 0 0
X0 vdd slo smid c pre a0 h0 x0 y0 canal rd=1e12 cab=0
Vf0 a0 0 0
X1 vdd slo smid c pre a1 h1 x1 y1 canal rd=1e12 cab=0
Vf1 a1 0 0.0003
X2 vdd slo smid c pre a2 h2 x2 y2 canal rd=1e12 cab=0
Vf2 a2 0 0.005
X3 vdd slo smid c pre a3 h3 x3 y3 canal rd=1e12 cab=0
Vf3 a3 0 0.01
X4 vdd slo smid c pre a4 h4 x4 y4 canal rd=1e12 cab=0
Vf4 a4 0 0.02
X5 vdd slo smid c pre a5 h5 x5 y5 canal rd=1e12 cab=0
Vf5 a5 0 0.03
X6 vdd slo smid c pre a6 h6 x6 y6 canal rd=1e12 cab=0
Vf6 a6 0 0.04
X7 vdd slo smid c pre a7 h7 x7 y7 canal rd=1e12 cab=0
Vf7 a7 0 0.05
X8 vdd slo smid c pre a8 h8 x8 y8 canal rd=1e12 cab=0
Vf8 a8 0 0.0503
X9 vdd slo smid c pre a9 h9 x9 y9 canal rd=1e12 cab=0
Vf9 a9 0 0.06
.control
tran 20n 1.2m
meas tran t0 when v(y0)=0.9 rise=1
echo T0B 0 $&t0
meas tran t1 when v(y1)=0.9 rise=1
echo T0B 0.0003 $&t1
meas tran t2 when v(y2)=0.9 rise=1
echo T0B 0.005 $&t2
meas tran t3 when v(y3)=0.9 rise=1
echo T0B 0.01 $&t3
meas tran t4 when v(y4)=0.9 rise=1
echo T0B 0.02 $&t4
meas tran t5 when v(y5)=0.9 rise=1
echo T0B 0.03 $&t5
meas tran t6 when v(y6)=0.9 rise=1
echo T0B 0.04 $&t6
meas tran t7 when v(y7)=0.9 rise=1
echo T0B 0.05 $&t7
meas tran t8 when v(y8)=0.9 rise=1
echo T0B 0.0503 $&t8
meas tran t9 when v(y9)=0.9 rise=1
echo T0B 0.06 $&t9
quit
.endc
.end
