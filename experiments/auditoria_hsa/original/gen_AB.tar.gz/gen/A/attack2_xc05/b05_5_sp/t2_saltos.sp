* b05 T2/T3: saltos de resistencia en 1 ns
.lib /foss/pdks/sky130A/libs.tech/ngspice/sky130.lib.spice tt
.include /foss/pdks/sky130A/libs.ref/sky130_fd_sc_hd/spice/sky130_fd_sc_hd.spice
.options gmin=1e-15 abstol=1e-15 reltol=1e-4
.temp 27
.subckt canal vdd slo smid c pre a h x y rd=100 cab=50f
XR1 vdd h 0 sky130_fd_pr__res_high_po_0p35 l=56
XR2 h 0 0 sky130_fd_pr__res_high_po_0p35 l=0.5
XRhi h a 0 sky130_fd_pr__res_xhigh_po_0p35 l=52
XMmid h smid m1 0 sky130_fd_pr__nfet_01v8 w=1 l=0.15
XRmid m1 a 0 sky130_fd_pr__res_xhigh_po_0p35 l=1.75
XMlo h slo a 0 sky130_fd_pr__nfet_01v8 w=5 l=0.15
Rdut a 0 r = {rd*exp(23.03*v(c))}
Cab a 0 {cab}
Cpar a 0 5f
Xc0 vdd vdd c1 0 sky130_fd_pr__nfet_01v8 w=1 l=1
Xc1 c1 c1 vb 0 sky130_fd_pr__nfet_01v8 w=1 l=1
Xc2 vb vb 0 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.15 m=16
Cf vb 0 1p
Xp x pre vdd vdd sky130_fd_pr__pfet_01v8 w=0.42 l=0.15
Xr x vb a 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.15
Xi x 0 0 vdd vdd y sky130_fd_sc_hd__inv_1
.ends
Vdd vdd 0 1.8
Vz z 0 0
Vup cu 0 pwl(0 0 2u 0 2.001u 1)
Vdn cd 0 pwl(0 1 2u 1 2.001u 0)
Xbajo_100_abre_0 vdd vdd z cu z a_bajo_100_abre_0 h_bajo_100_abre_0 x_bajo_100_abre_0 y_bajo_100_abre_0 canal rd=100 cab=0
Xbajo_100_abre_50f vdd vdd z cu z a_bajo_100_abre_50f h_bajo_100_abre_50f x_bajo_100_abre_50f y_bajo_100_abre_50f canal rd=100 cab=50f
Xbajo_100_cierra_0 vdd vdd z cd z a_bajo_100_cierra_0 h_bajo_100_cierra_0 x_bajo_100_cierra_0 y_bajo_100_cierra_0 canal rd=100 cab=0
Xbajo_100_cierra_50f vdd vdd z cd z a_bajo_100_cierra_50f h_bajo_100_cierra_50f x_bajo_100_cierra_50f y_bajo_100_cierra_50f canal rd=100 cab=50f
Xbajo_12k9_abre_0 vdd vdd z cu z a_bajo_12k9_abre_0 h_bajo_12k9_abre_0 x_bajo_12k9_abre_0 y_bajo_12k9_abre_0 canal rd=12906 cab=0
Xbajo_12k9_abre_50f vdd vdd z cu z a_bajo_12k9_abre_50f h_bajo_12k9_abre_50f x_bajo_12k9_abre_50f y_bajo_12k9_abre_50f canal rd=12906 cab=50f
Xbajo_12k9_cierra_0 vdd vdd z cd z a_bajo_12k9_cierra_0 h_bajo_12k9_cierra_0 x_bajo_12k9_cierra_0 y_bajo_12k9_cierra_0 canal rd=12906 cab=0
Xbajo_12k9_cierra_50f vdd vdd z cd z a_bajo_12k9_cierra_50f h_bajo_12k9_cierra_50f x_bajo_12k9_cierra_50f y_bajo_12k9_cierra_50f canal rd=12906 cab=50f
Xmedio_100_abre_0 vdd z vdd cu z a_medio_100_abre_0 h_medio_100_abre_0 x_medio_100_abre_0 y_medio_100_abre_0 canal rd=100 cab=0
Xmedio_100_abre_50f vdd z vdd cu z a_medio_100_abre_50f h_medio_100_abre_50f x_medio_100_abre_50f y_medio_100_abre_50f canal rd=100 cab=50f
Xmedio_100_cierra_0 vdd z vdd cd z a_medio_100_cierra_0 h_medio_100_cierra_0 x_medio_100_cierra_0 y_medio_100_cierra_0 canal rd=100 cab=0
Xmedio_100_cierra_50f vdd z vdd cd z a_medio_100_cierra_50f h_medio_100_cierra_50f x_medio_100_cierra_50f y_medio_100_cierra_50f canal rd=100 cab=50f
Xmedio_12k9_abre_0 vdd z vdd cu z a_medio_12k9_abre_0 h_medio_12k9_abre_0 x_medio_12k9_abre_0 y_medio_12k9_abre_0 canal rd=12906 cab=0
Xmedio_12k9_abre_50f vdd z vdd cu z a_medio_12k9_abre_50f h_medio_12k9_abre_50f x_medio_12k9_abre_50f y_medio_12k9_abre_50f canal rd=12906 cab=50f
Xmedio_12k9_cierra_0 vdd z vdd cd z a_medio_12k9_cierra_0 h_medio_12k9_cierra_0 x_medio_12k9_cierra_0 y_medio_12k9_cierra_0 canal rd=12906 cab=0
Xmedio_12k9_cierra_50f vdd z vdd cd z a_medio_12k9_cierra_50f h_medio_12k9_cierra_50f x_medio_12k9_cierra_50f y_medio_12k9_cierra_50f canal rd=12906 cab=50f
Xalto_100_abre_0 vdd z z cu z a_alto_100_abre_0 h_alto_100_abre_0 x_alto_100_abre_0 y_alto_100_abre_0 canal rd=100 cab=0
Xalto_100_abre_50f vdd z z cu z a_alto_100_abre_50f h_alto_100_abre_50f x_alto_100_abre_50f y_alto_100_abre_50f canal rd=100 cab=50f
Xalto_100_cierra_0 vdd z z cd z a_alto_100_cierra_0 h_alto_100_cierra_0 x_alto_100_cierra_0 y_alto_100_cierra_0 canal rd=100 cab=0
Xalto_100_cierra_50f vdd z z cd z a_alto_100_cierra_50f h_alto_100_cierra_50f x_alto_100_cierra_50f y_alto_100_cierra_50f canal rd=100 cab=50f
Xalto_12k9_abre_0 vdd z z cu z a_alto_12k9_abre_0 h_alto_12k9_abre_0 x_alto_12k9_abre_0 y_alto_12k9_abre_0 canal rd=12906 cab=0
Xalto_12k9_abre_50f vdd z z cu z a_alto_12k9_abre_50f h_alto_12k9_abre_50f x_alto_12k9_abre_50f y_alto_12k9_abre_50f canal rd=12906 cab=50f
Xalto_12k9_cierra_0 vdd z z cd z a_alto_12k9_cierra_0 h_alto_12k9_cierra_0 x_alto_12k9_cierra_0 y_alto_12k9_cierra_0 canal rd=12906 cab=0
Xalto_12k9_cierra_50f vdd z z cd z a_alto_12k9_cierra_50f h_alto_12k9_cierra_50f x_alto_12k9_cierra_50f y_alto_12k9_cierra_50f canal rd=12906 cab=50f
.control
tran 0.05n 6u 1.99u
meas tran mx_bajo_100_abre_0 max v(a_bajo_100_abre_0)
meas tran mn_bajo_100_abre_0 min v(a_bajo_100_abre_0)
meas tran v0_bajo_100_abre_0 find v(a_bajo_100_abre_0) at=1.9u
meas tran v1_bajo_100_abre_0 find v(a_bajo_100_abre_0) at=5.9u
meas tran hx_bajo_100_abre_0 max v(h_bajo_100_abre_0)
echo T2 rango=bajo R=100 abre cab=0 antes=$&v0_bajo_100_abre_0 despues=$&v1_bajo_100_abre_0 max=$&mx_bajo_100_abre_0 min=$&mn_bajo_100_abre_0 maxH=$&hx_bajo_100_abre_0
meas tran mx_bajo_100_abre_50f max v(a_bajo_100_abre_50f)
meas tran mn_bajo_100_abre_50f min v(a_bajo_100_abre_50f)
meas tran v0_bajo_100_abre_50f find v(a_bajo_100_abre_50f) at=1.9u
meas tran v1_bajo_100_abre_50f find v(a_bajo_100_abre_50f) at=5.9u
meas tran hx_bajo_100_abre_50f max v(h_bajo_100_abre_50f)
echo T2 rango=bajo R=100 abre cab=50f antes=$&v0_bajo_100_abre_50f despues=$&v1_bajo_100_abre_50f max=$&mx_bajo_100_abre_50f min=$&mn_bajo_100_abre_50f maxH=$&hx_bajo_100_abre_50f
meas tran mx_bajo_100_cierra_0 max v(a_bajo_100_cierra_0)
meas tran mn_bajo_100_cierra_0 min v(a_bajo_100_cierra_0)
meas tran v0_bajo_100_cierra_0 find v(a_bajo_100_cierra_0) at=1.9u
meas tran v1_bajo_100_cierra_0 find v(a_bajo_100_cierra_0) at=5.9u
meas tran hx_bajo_100_cierra_0 max v(h_bajo_100_cierra_0)
echo T2 rango=bajo R=100 cierra cab=0 antes=$&v0_bajo_100_cierra_0 despues=$&v1_bajo_100_cierra_0 max=$&mx_bajo_100_cierra_0 min=$&mn_bajo_100_cierra_0 maxH=$&hx_bajo_100_cierra_0
meas tran mx_bajo_100_cierra_50f max v(a_bajo_100_cierra_50f)
meas tran mn_bajo_100_cierra_50f min v(a_bajo_100_cierra_50f)
meas tran v0_bajo_100_cierra_50f find v(a_bajo_100_cierra_50f) at=1.9u
meas tran v1_bajo_100_cierra_50f find v(a_bajo_100_cierra_50f) at=5.9u
meas tran hx_bajo_100_cierra_50f max v(h_bajo_100_cierra_50f)
echo T2 rango=bajo R=100 cierra cab=50f antes=$&v0_bajo_100_cierra_50f despues=$&v1_bajo_100_cierra_50f max=$&mx_bajo_100_cierra_50f min=$&mn_bajo_100_cierra_50f maxH=$&hx_bajo_100_cierra_50f
meas tran mx_bajo_12k9_abre_0 max v(a_bajo_12k9_abre_0)
meas tran mn_bajo_12k9_abre_0 min v(a_bajo_12k9_abre_0)
meas tran v0_bajo_12k9_abre_0 find v(a_bajo_12k9_abre_0) at=1.9u
meas tran v1_bajo_12k9_abre_0 find v(a_bajo_12k9_abre_0) at=5.9u
meas tran hx_bajo_12k9_abre_0 max v(h_bajo_12k9_abre_0)
echo T2 rango=bajo R=12k9 abre cab=0 antes=$&v0_bajo_12k9_abre_0 despues=$&v1_bajo_12k9_abre_0 max=$&mx_bajo_12k9_abre_0 min=$&mn_bajo_12k9_abre_0 maxH=$&hx_bajo_12k9_abre_0
meas tran mx_bajo_12k9_abre_50f max v(a_bajo_12k9_abre_50f)
meas tran mn_bajo_12k9_abre_50f min v(a_bajo_12k9_abre_50f)
meas tran v0_bajo_12k9_abre_50f find v(a_bajo_12k9_abre_50f) at=1.9u
meas tran v1_bajo_12k9_abre_50f find v(a_bajo_12k9_abre_50f) at=5.9u
meas tran hx_bajo_12k9_abre_50f max v(h_bajo_12k9_abre_50f)
echo T2 rango=bajo R=12k9 abre cab=50f antes=$&v0_bajo_12k9_abre_50f despues=$&v1_bajo_12k9_abre_50f max=$&mx_bajo_12k9_abre_50f min=$&mn_bajo_12k9_abre_50f maxH=$&hx_bajo_12k9_abre_50f
meas tran mx_bajo_12k9_cierra_0 max v(a_bajo_12k9_cierra_0)
meas tran mn_bajo_12k9_cierra_0 min v(a_bajo_12k9_cierra_0)
meas tran v0_bajo_12k9_cierra_0 find v(a_bajo_12k9_cierra_0) at=1.9u
meas tran v1_bajo_12k9_cierra_0 find v(a_bajo_12k9_cierra_0) at=5.9u
meas tran hx_bajo_12k9_cierra_0 max v(h_bajo_12k9_cierra_0)
echo T2 rango=bajo R=12k9 cierra cab=0 antes=$&v0_bajo_12k9_cierra_0 despues=$&v1_bajo_12k9_cierra_0 max=$&mx_bajo_12k9_cierra_0 min=$&mn_bajo_12k9_cierra_0 maxH=$&hx_bajo_12k9_cierra_0
meas tran mx_bajo_12k9_cierra_50f max v(a_bajo_12k9_cierra_50f)
meas tran mn_bajo_12k9_cierra_50f min v(a_bajo_12k9_cierra_50f)
meas tran v0_bajo_12k9_cierra_50f find v(a_bajo_12k9_cierra_50f) at=1.9u
meas tran v1_bajo_12k9_cierra_50f find v(a_bajo_12k9_cierra_50f) at=5.9u
meas tran hx_bajo_12k9_cierra_50f max v(h_bajo_12k9_cierra_50f)
echo T2 rango=bajo R=12k9 cierra cab=50f antes=$&v0_bajo_12k9_cierra_50f despues=$&v1_bajo_12k9_cierra_50f max=$&mx_bajo_12k9_cierra_50f min=$&mn_bajo_12k9_cierra_50f maxH=$&hx_bajo_12k9_cierra_50f
meas tran mx_medio_100_abre_0 max v(a_medio_100_abre_0)
meas tran mn_medio_100_abre_0 min v(a_medio_100_abre_0)
meas tran v0_medio_100_abre_0 find v(a_medio_100_abre_0) at=1.9u
meas tran v1_medio_100_abre_0 find v(a_medio_100_abre_0) at=5.9u
meas tran hx_medio_100_abre_0 max v(h_medio_100_abre_0)
echo T2 rango=medio R=100 abre cab=0 antes=$&v0_medio_100_abre_0 despues=$&v1_medio_100_abre_0 max=$&mx_medio_100_abre_0 min=$&mn_medio_100_abre_0 maxH=$&hx_medio_100_abre_0
meas tran mx_medio_100_abre_50f max v(a_medio_100_abre_50f)
meas tran mn_medio_100_abre_50f min v(a_medio_100_abre_50f)
meas tran v0_medio_100_abre_50f find v(a_medio_100_abre_50f) at=1.9u
meas tran v1_medio_100_abre_50f find v(a_medio_100_abre_50f) at=5.9u
meas tran hx_medio_100_abre_50f max v(h_medio_100_abre_50f)
echo T2 rango=medio R=100 abre cab=50f antes=$&v0_medio_100_abre_50f despues=$&v1_medio_100_abre_50f max=$&mx_medio_100_abre_50f min=$&mn_medio_100_abre_50f maxH=$&hx_medio_100_abre_50f
meas tran mx_medio_100_cierra_0 max v(a_medio_100_cierra_0)
meas tran mn_medio_100_cierra_0 min v(a_medio_100_cierra_0)
meas tran v0_medio_100_cierra_0 find v(a_medio_100_cierra_0) at=1.9u
meas tran v1_medio_100_cierra_0 find v(a_medio_100_cierra_0) at=5.9u
meas tran hx_medio_100_cierra_0 max v(h_medio_100_cierra_0)
echo T2 rango=medio R=100 cierra cab=0 antes=$&v0_medio_100_cierra_0 despues=$&v1_medio_100_cierra_0 max=$&mx_medio_100_cierra_0 min=$&mn_medio_100_cierra_0 maxH=$&hx_medio_100_cierra_0
meas tran mx_medio_100_cierra_50f max v(a_medio_100_cierra_50f)
meas tran mn_medio_100_cierra_50f min v(a_medio_100_cierra_50f)
meas tran v0_medio_100_cierra_50f find v(a_medio_100_cierra_50f) at=1.9u
meas tran v1_medio_100_cierra_50f find v(a_medio_100_cierra_50f) at=5.9u
meas tran hx_medio_100_cierra_50f max v(h_medio_100_cierra_50f)
echo T2 rango=medio R=100 cierra cab=50f antes=$&v0_medio_100_cierra_50f despues=$&v1_medio_100_cierra_50f max=$&mx_medio_100_cierra_50f min=$&mn_medio_100_cierra_50f maxH=$&hx_medio_100_cierra_50f
meas tran mx_medio_12k9_abre_0 max v(a_medio_12k9_abre_0)
meas tran mn_medio_12k9_abre_0 min v(a_medio_12k9_abre_0)
meas tran v0_medio_12k9_abre_0 find v(a_medio_12k9_abre_0) at=1.9u
meas tran v1_medio_12k9_abre_0 find v(a_medio_12k9_abre_0) at=5.9u
meas tran hx_medio_12k9_abre_0 max v(h_medio_12k9_abre_0)
echo T2 rango=medio R=12k9 abre cab=0 antes=$&v0_medio_12k9_abre_0 despues=$&v1_medio_12k9_abre_0 max=$&mx_medio_12k9_abre_0 min=$&mn_medio_12k9_abre_0 maxH=$&hx_medio_12k9_abre_0
meas tran mx_medio_12k9_abre_50f max v(a_medio_12k9_abre_50f)
meas tran mn_medio_12k9_abre_50f min v(a_medio_12k9_abre_50f)
meas tran v0_medio_12k9_abre_50f find v(a_medio_12k9_abre_50f) at=1.9u
meas tran v1_medio_12k9_abre_50f find v(a_medio_12k9_abre_50f) at=5.9u
meas tran hx_medio_12k9_abre_50f max v(h_medio_12k9_abre_50f)
echo T2 rango=medio R=12k9 abre cab=50f antes=$&v0_medio_12k9_abre_50f despues=$&v1_medio_12k9_abre_50f max=$&mx_medio_12k9_abre_50f min=$&mn_medio_12k9_abre_50f maxH=$&hx_medio_12k9_abre_50f
meas tran mx_medio_12k9_cierra_0 max v(a_medio_12k9_cierra_0)
meas tran mn_medio_12k9_cierra_0 min v(a_medio_12k9_cierra_0)
meas tran v0_medio_12k9_cierra_0 find v(a_medio_12k9_cierra_0) at=1.9u
meas tran v1_medio_12k9_cierra_0 find v(a_medio_12k9_cierra_0) at=5.9u
meas tran hx_medio_12k9_cierra_0 max v(h_medio_12k9_cierra_0)
echo T2 rango=medio R=12k9 cierra cab=0 antes=$&v0_medio_12k9_cierra_0 despues=$&v1_medio_12k9_cierra_0 max=$&mx_medio_12k9_cierra_0 min=$&mn_medio_12k9_cierra_0 maxH=$&hx_medio_12k9_cierra_0
meas tran mx_medio_12k9_cierra_50f max v(a_medio_12k9_cierra_50f)
meas tran mn_medio_12k9_cierra_50f min v(a_medio_12k9_cierra_50f)
meas tran v0_medio_12k9_cierra_50f find v(a_medio_12k9_cierra_50f) at=1.9u
meas tran v1_medio_12k9_cierra_50f find v(a_medio_12k9_cierra_50f) at=5.9u
meas tran hx_medio_12k9_cierra_50f max v(h_medio_12k9_cierra_50f)
echo T2 rango=medio R=12k9 cierra cab=50f antes=$&v0_medio_12k9_cierra_50f despues=$&v1_medio_12k9_cierra_50f max=$&mx_medio_12k9_cierra_50f min=$&mn_medio_12k9_cierra_50f maxH=$&hx_medio_12k9_cierra_50f
meas tran mx_alto_100_abre_0 max v(a_alto_100_abre_0)
meas tran mn_alto_100_abre_0 min v(a_alto_100_abre_0)
meas tran v0_alto_100_abre_0 find v(a_alto_100_abre_0) at=1.9u
meas tran v1_alto_100_abre_0 find v(a_alto_100_abre_0) at=5.9u
meas tran hx_alto_100_abre_0 max v(h_alto_100_abre_0)
echo T2 rango=alto R=100 abre cab=0 antes=$&v0_alto_100_abre_0 despues=$&v1_alto_100_abre_0 max=$&mx_alto_100_abre_0 min=$&mn_alto_100_abre_0 maxH=$&hx_alto_100_abre_0
meas tran mx_alto_100_abre_50f max v(a_alto_100_abre_50f)
meas tran mn_alto_100_abre_50f min v(a_alto_100_abre_50f)
meas tran v0_alto_100_abre_50f find v(a_alto_100_abre_50f) at=1.9u
meas tran v1_alto_100_abre_50f find v(a_alto_100_abre_50f) at=5.9u
meas tran hx_alto_100_abre_50f max v(h_alto_100_abre_50f)
echo T2 rango=alto R=100 abre cab=50f antes=$&v0_alto_100_abre_50f despues=$&v1_alto_100_abre_50f max=$&mx_alto_100_abre_50f min=$&mn_alto_100_abre_50f maxH=$&hx_alto_100_abre_50f
meas tran mx_alto_100_cierra_0 max v(a_alto_100_cierra_0)
meas tran mn_alto_100_cierra_0 min v(a_alto_100_cierra_0)
meas tran v0_alto_100_cierra_0 find v(a_alto_100_cierra_0) at=1.9u
meas tran v1_alto_100_cierra_0 find v(a_alto_100_cierra_0) at=5.9u
meas tran hx_alto_100_cierra_0 max v(h_alto_100_cierra_0)
echo T2 rango=alto R=100 cierra cab=0 antes=$&v0_alto_100_cierra_0 despues=$&v1_alto_100_cierra_0 max=$&mx_alto_100_cierra_0 min=$&mn_alto_100_cierra_0 maxH=$&hx_alto_100_cierra_0
meas tran mx_alto_100_cierra_50f max v(a_alto_100_cierra_50f)
meas tran mn_alto_100_cierra_50f min v(a_alto_100_cierra_50f)
meas tran v0_alto_100_cierra_50f find v(a_alto_100_cierra_50f) at=1.9u
meas tran v1_alto_100_cierra_50f find v(a_alto_100_cierra_50f) at=5.9u
meas tran hx_alto_100_cierra_50f max v(h_alto_100_cierra_50f)
echo T2 rango=alto R=100 cierra cab=50f antes=$&v0_alto_100_cierra_50f despues=$&v1_alto_100_cierra_50f max=$&mx_alto_100_cierra_50f min=$&mn_alto_100_cierra_50f maxH=$&hx_alto_100_cierra_50f
meas tran mx_alto_12k9_abre_0 max v(a_alto_12k9_abre_0)
meas tran mn_alto_12k9_abre_0 min v(a_alto_12k9_abre_0)
meas tran v0_alto_12k9_abre_0 find v(a_alto_12k9_abre_0) at=1.9u
meas tran v1_alto_12k9_abre_0 find v(a_alto_12k9_abre_0) at=5.9u
meas tran hx_alto_12k9_abre_0 max v(h_alto_12k9_abre_0)
echo T2 rango=alto R=12k9 abre cab=0 antes=$&v0_alto_12k9_abre_0 despues=$&v1_alto_12k9_abre_0 max=$&mx_alto_12k9_abre_0 min=$&mn_alto_12k9_abre_0 maxH=$&hx_alto_12k9_abre_0
meas tran mx_alto_12k9_abre_50f max v(a_alto_12k9_abre_50f)
meas tran mn_alto_12k9_abre_50f min v(a_alto_12k9_abre_50f)
meas tran v0_alto_12k9_abre_50f find v(a_alto_12k9_abre_50f) at=1.9u
meas tran v1_alto_12k9_abre_50f find v(a_alto_12k9_abre_50f) at=5.9u
meas tran hx_alto_12k9_abre_50f max v(h_alto_12k9_abre_50f)
echo T2 rango=alto R=12k9 abre cab=50f antes=$&v0_alto_12k9_abre_50f despues=$&v1_alto_12k9_abre_50f max=$&mx_alto_12k9_abre_50f min=$&mn_alto_12k9_abre_50f maxH=$&hx_alto_12k9_abre_50f
meas tran mx_alto_12k9_cierra_0 max v(a_alto_12k9_cierra_0)
meas tran mn_alto_12k9_cierra_0 min v(a_alto_12k9_cierra_0)
meas tran v0_alto_12k9_cierra_0 find v(a_alto_12k9_cierra_0) at=1.9u
meas tran v1_alto_12k9_cierra_0 find v(a_alto_12k9_cierra_0) at=5.9u
meas tran hx_alto_12k9_cierra_0 max v(h_alto_12k9_cierra_0)
echo T2 rango=alto R=12k9 cierra cab=0 antes=$&v0_alto_12k9_cierra_0 despues=$&v1_alto_12k9_cierra_0 max=$&mx_alto_12k9_cierra_0 min=$&mn_alto_12k9_cierra_0 maxH=$&hx_alto_12k9_cierra_0
meas tran mx_alto_12k9_cierra_50f max v(a_alto_12k9_cierra_50f)
meas tran mn_alto_12k9_cierra_50f min v(a_alto_12k9_cierra_50f)
meas tran v0_alto_12k9_cierra_50f find v(a_alto_12k9_cierra_50f) at=1.9u
meas tran v1_alto_12k9_cierra_50f find v(a_alto_12k9_cierra_50f) at=5.9u
meas tran hx_alto_12k9_cierra_50f max v(h_alto_12k9_cierra_50f)
echo T2 rango=alto R=12k9 cierra cab=50f antes=$&v0_alto_12k9_cierra_50f despues=$&v1_alto_12k9_cierra_50f max=$&mx_alto_12k9_cierra_50f min=$&mn_alto_12k9_cierra_50f maxH=$&hx_alto_12k9_cierra_50f
set wr_singlescale
set wr_vecnames
option numdgt=6
wrdata /w/t2_trazas.dat v(a_alto_100_abre_0) v(a_alto_100_abre_50f) v(a_bajo_100_abre_0) v(a_medio_100_abre_0) v(a_alto_100_cierra_50f)
quit
.endc
.end
