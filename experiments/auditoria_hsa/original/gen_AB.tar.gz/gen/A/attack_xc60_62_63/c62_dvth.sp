* c62 dVth/dL
.lib /foss/pdks/sky130A/libs.tech/ngspice/sky130.lib.spice tt
.temp 27
Vg g 0 0
Vgp gp 0 0
.options gmin=1e-18 abstol=1e-18 reltol=1e-6
Vn0 dn0 0 0.9
Xn0 dn0 g 0 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.15
Vp0 dp0 0 -0.9
Xp0 dp0 gp 0 0 sky130_fd_pr__pfet_01v8 w=0.42 l=0.15
Vn1 dn1 0 0.9
Xn1 dn1 g 0 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.152
Vp1 dp1 0 -0.9
Xp1 dp1 gp 0 0 sky130_fd_pr__pfet_01v8 w=0.42 l=0.152
Vn2 dn2 0 0.9
Xn2 dn2 g 0 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.155
Vp2 dp2 0 -0.9
Xp2 dp2 gp 0 0 sky130_fd_pr__pfet_01v8 w=0.42 l=0.155
Vn3 dn3 0 0.9
Xn3 dn3 g 0 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.16
Vp3 dp3 0 -0.9
Xp3 dp3 gp 0 0 sky130_fd_pr__pfet_01v8 w=0.42 l=0.16
Vn4 dn4 0 0.9
Xn4 dn4 g 0 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.165
Vp4 dp4 0 -0.9
Xp4 dp4 gp 0 0 sky130_fd_pr__pfet_01v8 w=0.42 l=0.165
Vn5 dn5 0 0.9
Xn5 dn5 g 0 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.17
Vp5 dp5 0 -0.9
Xp5 dp5 gp 0 0 sky130_fd_pr__pfet_01v8 w=0.42 l=0.17
Vn6 dn6 0 0.9
Xn6 dn6 g 0 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.18
Vp6 dp6 0 -0.9
Xp6 dp6 gp 0 0 sky130_fd_pr__pfet_01v8 w=0.42 l=0.18
Vn7 dn7 0 0.9
Xn7 dn7 g 0 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.2
Vp7 dp7 0 -0.9
Xp7 dp7 gp 0 0 sky130_fd_pr__pfet_01v8 w=0.42 l=0.2
Vn8 dn8 0 0.9
Xn8 dn8 g 0 0 sky130_fd_pr__nfet_01v8 w=0.42 l=0.25
Vp8 dp8 0 -0.9
Xp8 dp8 gp 0 0 sky130_fd_pr__pfet_01v8 w=0.42 l=0.25
.control
dc Vg 0 0.6 0.01
wrdata c62_dvth_n.dat i(Vn0) i(Vn1) i(Vn2) i(Vn3) i(Vn4) i(Vn5) i(Vn6) i(Vn7) i(Vn8)
dc Vgp 0 -0.6 -0.01
wrdata c62_dvth_p.dat i(Vp0) i(Vp1) i(Vp2) i(Vp3) i(Vp4) i(Vp5) i(Vp6) i(Vp7) i(Vp8)
quit
.endc
.end
