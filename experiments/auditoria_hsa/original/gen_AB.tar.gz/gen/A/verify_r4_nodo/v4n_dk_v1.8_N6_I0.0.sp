* v4n Dickson pfet_g5v0d10v5 vdd=1.8 N=6 IL=0.000e+00
.lib /pdk/libs.tech/ngspice/sky130.lib.spice tt
.temp 27
Vdd n0 0 1.8
Vp1 p1 0 pulse(0 1.8 2n 1n 1n 45n 100n)
Vp2 p2 0 pulse(0 1.8 52n 1n 1n 45n 100n)
XC1 n1 p1 sky130_fd_pr__cap_mim_m3_1 w=22 l=22
Cp1 n1 0 0.1p
XC2 n2 p2 sky130_fd_pr__cap_mim_m3_1 w=22 l=22
Cp2 n2 0 0.1p
XC3 n3 p1 sky130_fd_pr__cap_mim_m3_1 w=22 l=22
Cp3 n3 0 0.1p
XC4 n4 p2 sky130_fd_pr__cap_mim_m3_1 w=22 l=22
Cp4 n4 0 0.1p
XC5 n5 p1 sky130_fd_pr__cap_mim_m3_1 w=22 l=22
Cp5 n5 0 0.1p
XC6 n6 p2 sky130_fd_pr__cap_mim_m3_1 w=22 l=22
Cp6 n6 0 0.1p
XM1 n1 n1 n0 n1 sky130_fd_pr__pfet_g5v0d10v5 w=5 l=0.5 nf=1
Dnw1 0 n1 sky130_fd_pr__model__parasitic__diode_ps2nw area=100e-12
XM2 n2 n2 n1 n2 sky130_fd_pr__pfet_g5v0d10v5 w=5 l=0.5 nf=1
Dnw2 0 n2 sky130_fd_pr__model__parasitic__diode_ps2nw area=100e-12
XM3 n3 n3 n2 n3 sky130_fd_pr__pfet_g5v0d10v5 w=5 l=0.5 nf=1
Dnw3 0 n3 sky130_fd_pr__model__parasitic__diode_ps2nw area=100e-12
XM4 n4 n4 n3 n4 sky130_fd_pr__pfet_g5v0d10v5 w=5 l=0.5 nf=1
Dnw4 0 n4 sky130_fd_pr__model__parasitic__diode_ps2nw area=100e-12
XM5 n5 n5 n4 n5 sky130_fd_pr__pfet_g5v0d10v5 w=5 l=0.5 nf=1
Dnw5 0 n5 sky130_fd_pr__model__parasitic__diode_ps2nw area=100e-12
XM6 n6 n6 n5 n6 sky130_fd_pr__pfet_g5v0d10v5 w=5 l=0.5 nf=1
Dnw6 0 n6 sky130_fd_pr__model__parasitic__diode_ps2nw area=100e-12
XM7 out out n6 out sky130_fd_pr__pfet_g5v0d10v5 w=5 l=0.5 nf=1
Dnw7 0 out sky130_fd_pr__model__parasitic__diode_ps2nw area=100e-12
Cout out 0 2p
IL out 0 0.000e+00
.control
tran 0.5n 8e-05 0 1n
meas tran vout avg v(out) from=7.800000000000001e-05 to=8e-05
meas tran vout_prev avg v(out) from=6.8e-05 to=7.000000000000001e-05
let d1 = v(n1)-v(n0)
meas tran dmax1 max d1 from=7.6e-05 to=8e-05
meas tran dmin1 min d1 from=7.6e-05 to=8e-05
let d2 = v(n2)-v(n1)
meas tran dmax2 max d2 from=7.6e-05 to=8e-05
meas tran dmin2 min d2 from=7.6e-05 to=8e-05
let d3 = v(n3)-v(n2)
meas tran dmax3 max d3 from=7.6e-05 to=8e-05
meas tran dmin3 min d3 from=7.6e-05 to=8e-05
let d4 = v(n4)-v(n3)
meas tran dmax4 max d4 from=7.6e-05 to=8e-05
meas tran dmin4 min d4 from=7.6e-05 to=8e-05
let d5 = v(n5)-v(n4)
meas tran dmax5 max d5 from=7.6e-05 to=8e-05
meas tran dmin5 min d5 from=7.6e-05 to=8e-05
let d6 = v(n6)-v(n5)
meas tran dmax6 max d6 from=7.6e-05 to=8e-05
meas tran dmin6 min d6 from=7.6e-05 to=8e-05
let d7 = v(out)-v(n6)
meas tran dmax7 max d7 from=7.6e-05 to=8e-05
meas tran dmin7 min d7 from=7.6e-05 to=8e-05
meas tran ivdd avg i(Vdd) from=7.800000000000001e-05 to=8e-05
meas tran ip1 avg i(Vp1) from=7.800000000000001e-05 to=8e-05
meas tran ip2 avg i(Vp2) from=7.800000000000001e-05 to=8e-05
echo RES v1.8_N6_I0.0 $&vout $&vout_prev $&dmax1 $&dmin1 $&dmax2 $&dmin2 $&dmax3 $&dmin3 $&dmax4 $&dmin4 $&dmax5 $&dmin5 $&dmax6 $&dmin6 $&dmax7 $&dmin7 $&ivdd $&ip1 $&ip2
.endc
.end
